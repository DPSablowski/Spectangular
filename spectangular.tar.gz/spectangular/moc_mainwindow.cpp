/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[63];
    char stringdata0[1361];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 5), // "Input"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(4, 38, 21), // "on_checkBox_2_clicked"
QT_MOC_LITERAL(5, 60, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(6, 84, 9), // "read_data"
QT_MOC_LITERAL(7, 94, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(8, 118, 35), // "on_actionSpectrum_Plotter_tri..."
QT_MOC_LITERAL(9, 154, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(10, 179, 29), // "on_actionBug_Report_triggered"
QT_MOC_LITERAL(11, 209, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(12, 233, 21), // "on_checkBox_5_clicked"
QT_MOC_LITERAL(13, 255, 21), // "on_checkBox_6_clicked"
QT_MOC_LITERAL(14, 277, 21), // "on_checkBox_7_clicked"
QT_MOC_LITERAL(15, 299, 29), // "on_lineEdit_4_editingFinished"
QT_MOC_LITERAL(16, 329, 30), // "on_actionCorrelation_triggered"
QT_MOC_LITERAL(17, 360, 25), // "on_lineEdit_9_textChanged"
QT_MOC_LITERAL(18, 386, 26), // "on_lineEdit_11_textChanged"
QT_MOC_LITERAL(19, 413, 26), // "on_lineEdit_12_textChanged"
QT_MOC_LITERAL(20, 440, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(21, 472, 15), // "ConstructMatrix"
QT_MOC_LITERAL(22, 488, 13), // "DivideConquer"
QT_MOC_LITERAL(23, 502, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(24, 526, 25), // "on_spinBox_3_valueChanged"
QT_MOC_LITERAL(25, 552, 21), // "on_checkBox_9_clicked"
QT_MOC_LITERAL(26, 574, 22), // "on_checkBox_11_clicked"
QT_MOC_LITERAL(27, 597, 31), // "on_doubleSpinBox_4_valueChanged"
QT_MOC_LITERAL(28, 629, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(29, 653, 22), // "on_checkBox_12_clicked"
QT_MOC_LITERAL(30, 676, 21), // "on_checkBox_4_clicked"
QT_MOC_LITERAL(31, 698, 21), // "on_checkBox_3_clicked"
QT_MOC_LITERAL(32, 720, 22), // "on_checkBox_14_clicked"
QT_MOC_LITERAL(33, 743, 22), // "on_checkBox_15_clicked"
QT_MOC_LITERAL(34, 766, 25), // "on_actionEditor_triggered"
QT_MOC_LITERAL(35, 792, 22), // "on_checkBox_16_clicked"
QT_MOC_LITERAL(36, 815, 11), // "VAmplitudeA"
QT_MOC_LITERAL(37, 827, 11), // "VAmplitudeB"
QT_MOC_LITERAL(38, 839, 29), // "on_actionArithmetic_triggered"
QT_MOC_LITERAL(39, 869, 25), // "on_actionManual_triggered"
QT_MOC_LITERAL(40, 895, 15), // "ErrorEstimation"
QT_MOC_LITERAL(41, 911, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(42, 935, 18), // "ComputeDifferences"
QT_MOC_LITERAL(43, 954, 12), // "Optimisation"
QT_MOC_LITERAL(44, 967, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(45, 991, 22), // "on_checkBox_34_clicked"
QT_MOC_LITERAL(46, 1014, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(47, 1038, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(48, 1063, 8), // "findroot"
QT_MOC_LITERAL(49, 1072, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(50, 1097, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(51, 1122, 25), // "on_spinBox_8_valueChanged"
QT_MOC_LITERAL(52, 1148, 22), // "on_checkBox_22_clicked"
QT_MOC_LITERAL(53, 1171, 22), // "on_checkBox_20_clicked"
QT_MOC_LITERAL(54, 1194, 22), // "on_checkBox_21_clicked"
QT_MOC_LITERAL(55, 1217, 22), // "on_checkBox_24_clicked"
QT_MOC_LITERAL(56, 1240, 22), // "on_checkBox_25_clicked"
QT_MOC_LITERAL(57, 1263, 16), // "showPointToolTip"
QT_MOC_LITERAL(58, 1280, 12), // "QMouseEvent*"
QT_MOC_LITERAL(59, 1293, 5), // "event"
QT_MOC_LITERAL(60, 1299, 18), // "showPointToolTip_3"
QT_MOC_LITERAL(61, 1318, 22), // "on_checkBox_27_clicked"
QT_MOC_LITERAL(62, 1341, 19) // "plot_functionvalues"

    },
    "MainWindow\0Input\0\0on_checkBox_clicked\0"
    "on_checkBox_2_clicked\0on_pushButton_2_clicked\0"
    "read_data\0on_pushButton_3_clicked\0"
    "on_actionSpectrum_Plotter_triggered\0"
    "on_actionAbout_triggered\0"
    "on_actionBug_Report_triggered\0"
    "on_pushButton_5_clicked\0on_checkBox_5_clicked\0"
    "on_checkBox_6_clicked\0on_checkBox_7_clicked\0"
    "on_lineEdit_4_editingFinished\0"
    "on_actionCorrelation_triggered\0"
    "on_lineEdit_9_textChanged\0"
    "on_lineEdit_11_textChanged\0"
    "on_lineEdit_12_textChanged\0"
    "on_comboBox_currentIndexChanged\0"
    "ConstructMatrix\0DivideConquer\0"
    "on_pushButton_6_clicked\0"
    "on_spinBox_3_valueChanged\0"
    "on_checkBox_9_clicked\0on_checkBox_11_clicked\0"
    "on_doubleSpinBox_4_valueChanged\0"
    "on_pushButton_7_clicked\0on_checkBox_12_clicked\0"
    "on_checkBox_4_clicked\0on_checkBox_3_clicked\0"
    "on_checkBox_14_clicked\0on_checkBox_15_clicked\0"
    "on_actionEditor_triggered\0"
    "on_checkBox_16_clicked\0VAmplitudeA\0"
    "VAmplitudeB\0on_actionArithmetic_triggered\0"
    "on_actionManual_triggered\0ErrorEstimation\0"
    "on_pushButton_8_clicked\0ComputeDifferences\0"
    "Optimisation\0on_pushButton_4_clicked\0"
    "on_checkBox_34_clicked\0on_pushButton_9_clicked\0"
    "on_pushButton_10_clicked\0findroot\0"
    "on_pushButton_11_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_spinBox_8_valueChanged\0"
    "on_checkBox_22_clicked\0on_checkBox_20_clicked\0"
    "on_checkBox_21_clicked\0on_checkBox_24_clicked\0"
    "on_checkBox_25_clicked\0showPointToolTip\0"
    "QMouseEvent*\0event\0showPointToolTip_3\0"
    "on_checkBox_27_clicked\0plot_functionvalues"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      59,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  309,    2, 0x08 /* Private */,
       3,    0,  310,    2, 0x08 /* Private */,
       4,    0,  311,    2, 0x08 /* Private */,
       5,    0,  312,    2, 0x08 /* Private */,
       6,    0,  313,    2, 0x08 /* Private */,
       7,    0,  314,    2, 0x08 /* Private */,
       8,    0,  315,    2, 0x08 /* Private */,
       9,    0,  316,    2, 0x08 /* Private */,
      10,    0,  317,    2, 0x08 /* Private */,
      11,    0,  318,    2, 0x08 /* Private */,
      12,    0,  319,    2, 0x08 /* Private */,
      13,    0,  320,    2, 0x08 /* Private */,
      14,    0,  321,    2, 0x08 /* Private */,
      15,    0,  322,    2, 0x08 /* Private */,
      16,    0,  323,    2, 0x08 /* Private */,
      17,    0,  324,    2, 0x08 /* Private */,
      18,    0,  325,    2, 0x08 /* Private */,
      19,    0,  326,    2, 0x08 /* Private */,
      20,    0,  327,    2, 0x08 /* Private */,
      21,    0,  328,    2, 0x08 /* Private */,
      22,    0,  329,    2, 0x08 /* Private */,
      23,    0,  330,    2, 0x08 /* Private */,
      24,    0,  331,    2, 0x08 /* Private */,
      25,    0,  332,    2, 0x08 /* Private */,
      26,    0,  333,    2, 0x08 /* Private */,
      27,    0,  334,    2, 0x08 /* Private */,
      28,    0,  335,    2, 0x08 /* Private */,
      29,    0,  336,    2, 0x08 /* Private */,
      30,    0,  337,    2, 0x08 /* Private */,
      31,    0,  338,    2, 0x08 /* Private */,
      32,    0,  339,    2, 0x08 /* Private */,
      33,    0,  340,    2, 0x08 /* Private */,
      34,    0,  341,    2, 0x08 /* Private */,
      35,    0,  342,    2, 0x08 /* Private */,
      36,    0,  343,    2, 0x08 /* Private */,
      37,    0,  344,    2, 0x08 /* Private */,
      38,    0,  345,    2, 0x08 /* Private */,
      39,    0,  346,    2, 0x08 /* Private */,
      40,    0,  347,    2, 0x08 /* Private */,
      41,    0,  348,    2, 0x08 /* Private */,
      42,    0,  349,    2, 0x08 /* Private */,
      43,    0,  350,    2, 0x08 /* Private */,
      44,    0,  351,    2, 0x08 /* Private */,
      45,    0,  352,    2, 0x08 /* Private */,
      46,    0,  353,    2, 0x08 /* Private */,
      47,    0,  354,    2, 0x08 /* Private */,
      48,    0,  355,    2, 0x08 /* Private */,
      49,    0,  356,    2, 0x08 /* Private */,
      50,    0,  357,    2, 0x08 /* Private */,
      51,    0,  358,    2, 0x08 /* Private */,
      52,    0,  359,    2, 0x08 /* Private */,
      53,    0,  360,    2, 0x08 /* Private */,
      54,    0,  361,    2, 0x08 /* Private */,
      55,    0,  362,    2, 0x08 /* Private */,
      56,    0,  363,    2, 0x08 /* Private */,
      57,    1,  364,    2, 0x08 /* Private */,
      60,    1,  367,    2, 0x08 /* Private */,
      61,    0,  370,    2, 0x08 /* Private */,
      62,    0,  371,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Double,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 58,   59,
    QMetaType::Void, 0x80000000 | 58,   59,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Input(); break;
        case 1: _t->on_checkBox_clicked(); break;
        case 2: _t->on_checkBox_2_clicked(); break;
        case 3: _t->on_pushButton_2_clicked(); break;
        case 4: _t->read_data(); break;
        case 5: _t->on_pushButton_3_clicked(); break;
        case 6: _t->on_actionSpectrum_Plotter_triggered(); break;
        case 7: _t->on_actionAbout_triggered(); break;
        case 8: _t->on_actionBug_Report_triggered(); break;
        case 9: _t->on_pushButton_5_clicked(); break;
        case 10: _t->on_checkBox_5_clicked(); break;
        case 11: _t->on_checkBox_6_clicked(); break;
        case 12: _t->on_checkBox_7_clicked(); break;
        case 13: _t->on_lineEdit_4_editingFinished(); break;
        case 14: _t->on_actionCorrelation_triggered(); break;
        case 15: _t->on_lineEdit_9_textChanged(); break;
        case 16: _t->on_lineEdit_11_textChanged(); break;
        case 17: _t->on_lineEdit_12_textChanged(); break;
        case 18: _t->on_comboBox_currentIndexChanged(); break;
        case 19: _t->ConstructMatrix(); break;
        case 20: { double _r = _t->DivideConquer();
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 21: _t->on_pushButton_6_clicked(); break;
        case 22: _t->on_spinBox_3_valueChanged(); break;
        case 23: _t->on_checkBox_9_clicked(); break;
        case 24: _t->on_checkBox_11_clicked(); break;
        case 25: _t->on_doubleSpinBox_4_valueChanged(); break;
        case 26: _t->on_pushButton_7_clicked(); break;
        case 27: _t->on_checkBox_12_clicked(); break;
        case 28: _t->on_checkBox_4_clicked(); break;
        case 29: _t->on_checkBox_3_clicked(); break;
        case 30: _t->on_checkBox_14_clicked(); break;
        case 31: _t->on_checkBox_15_clicked(); break;
        case 32: _t->on_actionEditor_triggered(); break;
        case 33: _t->on_checkBox_16_clicked(); break;
        case 34: _t->VAmplitudeA(); break;
        case 35: _t->VAmplitudeB(); break;
        case 36: _t->on_actionArithmetic_triggered(); break;
        case 37: _t->on_actionManual_triggered(); break;
        case 38: _t->ErrorEstimation(); break;
        case 39: _t->on_pushButton_8_clicked(); break;
        case 40: _t->ComputeDifferences(); break;
        case 41: _t->Optimisation(); break;
        case 42: _t->on_pushButton_4_clicked(); break;
        case 43: _t->on_checkBox_34_clicked(); break;
        case 44: _t->on_pushButton_9_clicked(); break;
        case 45: _t->on_pushButton_10_clicked(); break;
        case 46: _t->findroot(); break;
        case 47: _t->on_pushButton_11_clicked(); break;
        case 48: _t->on_pushButton_12_clicked(); break;
        case 49: _t->on_spinBox_8_valueChanged(); break;
        case 50: _t->on_checkBox_22_clicked(); break;
        case 51: _t->on_checkBox_20_clicked(); break;
        case 52: _t->on_checkBox_21_clicked(); break;
        case 53: _t->on_checkBox_24_clicked(); break;
        case 54: _t->on_checkBox_25_clicked(); break;
        case 55: _t->showPointToolTip((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 56: _t->showPointToolTip_3((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 57: _t->on_checkBox_27_clicked(); break;
        case 58: _t->plot_functionvalues(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 59)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 59;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 59)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 59;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
