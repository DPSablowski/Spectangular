/********************************************************************************
** Form generated from reading UI file 'edit.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDIT_H
#define UI_EDIT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Edit
{
public:
    QGridLayout *gridLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QSpinBox *spinBox;
    QLabel *label_13;
    QDoubleSpinBox *doubleSpinBox_20;
    QSpacerItem *horizontalSpacer_2;
    QFrame *line;
    QHBoxLayout *horizontalLayout_22;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QTableWidget *tableWidget;
    QFrame *line_2;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_3;
    QTableWidget *tableWidget_2;
    QFrame *line_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_4;
    QTableWidget *tableWidget_3;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_11;
    QFrame *line_4;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_6;
    QDoubleSpinBox *doubleSpinBox;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_7;
    QDoubleSpinBox *doubleSpinBox_2;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_8;
    QDoubleSpinBox *doubleSpinBox_3;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_9;
    QDoubleSpinBox *doubleSpinBox_4;
    QHBoxLayout *horizontalLayout_12;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QFrame *line_8;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_10;
    QDoubleSpinBox *doubleSpinBox_5;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_23;
    QDoubleSpinBox *doubleSpinBox_13;
    QHBoxLayout *horizontalLayout_26;
    QLabel *label_24;
    QDoubleSpinBox *doubleSpinBox_14;
    QHBoxLayout *horizontalLayout_27;
    QLabel *label_25;
    QDoubleSpinBox *doubleSpinBox_15;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_26;
    QDoubleSpinBox *doubleSpinBox_16;
    QHBoxLayout *horizontalLayout_29;
    QLabel *label_27;
    QDoubleSpinBox *doubleSpinBox_17;
    QHBoxLayout *horizontalLayout_30;
    QLabel *label_28;
    QDoubleSpinBox *doubleSpinBox_18;
    QHBoxLayout *horizontalLayout_31;
    QLabel *label_29;
    QDoubleSpinBox *doubleSpinBox_19;
    QHBoxLayout *horizontalLayout_32;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QFrame *line_5;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton;
    QFrame *line_6;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_14;
    QHBoxLayout *horizontalLayout_21;
    QLabel *label_15;
    QDoubleSpinBox *doubleSpinBox_6;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_21;
    QDoubleSpinBox *doubleSpinBox_7;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_16;
    QDoubleSpinBox *doubleSpinBox_8;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_17;
    QDoubleSpinBox *doubleSpinBox_9;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_18;
    QDoubleSpinBox *doubleSpinBox_10;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_19;
    QDoubleSpinBox *doubleSpinBox_11;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_20;
    QDoubleSpinBox *doubleSpinBox_12;
    QHBoxLayout *horizontalLayout_23;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QHBoxLayout *horizontalLayout_24;
    QComboBox *comboBox;
    QPushButton *pushButton_10;
    QFrame *line_7;
    QLabel *label_22;
    QHBoxLayout *horizontalLayout_33;
    QLabel *label_30;
    QLineEdit *lineEdit_3;
    QHBoxLayout *horizontalLayout_8;
    QPushButton *pushButton_5;
    QLineEdit *lineEdit_2;
    QLabel *label_11;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *pushButton_4;
    QLineEdit *lineEdit;
    QLabel *label_12;
    QSpacerItem *verticalSpacer_2;

    void setupUi(QDialog *Edit)
    {
        if (Edit->objectName().isEmpty())
            Edit->setObjectName(QStringLiteral("Edit"));
        Edit->resize(1204, 714);
        gridLayout = new QGridLayout(Edit);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        scrollArea = new QScrollArea(Edit);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1184, 694));
        verticalLayout_6 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(scrollAreaWidgetContents);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout->addWidget(label_2);

        spinBox = new QSpinBox(scrollAreaWidgetContents);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
        spinBox->setSizePolicy(sizePolicy);
        spinBox->setMaximum(999);

        horizontalLayout->addWidget(spinBox);

        label_13 = new QLabel(scrollAreaWidgetContents);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout->addWidget(label_13);

        doubleSpinBox_20 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_20->setObjectName(QStringLiteral("doubleSpinBox_20"));
        doubleSpinBox_20->setDecimals(5);

        horizontalLayout->addWidget(doubleSpinBox_20);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout_6->addLayout(horizontalLayout);

        line = new QFrame(scrollAreaWidgetContents);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_6->addWidget(line);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(scrollAreaWidgetContents);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        tableWidget = new QTableWidget(scrollAreaWidgetContents);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));

        verticalLayout->addWidget(tableWidget);


        horizontalLayout_14->addLayout(verticalLayout);

        line_2 = new QFrame(scrollAreaWidgetContents);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        horizontalLayout_14->addWidget(line_2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_3 = new QLabel(scrollAreaWidgetContents);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_4->addWidget(label_3);

        tableWidget_2 = new QTableWidget(scrollAreaWidgetContents);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));

        verticalLayout_4->addWidget(tableWidget_2);


        horizontalLayout_14->addLayout(verticalLayout_4);

        line_3 = new QFrame(scrollAreaWidgetContents);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::VLine);
        line_3->setFrameShadow(QFrame::Sunken);

        horizontalLayout_14->addWidget(line_3);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_4 = new QLabel(scrollAreaWidgetContents);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_3->addWidget(label_4);

        tableWidget_3 = new QTableWidget(scrollAreaWidgetContents);
        tableWidget_3->setObjectName(QStringLiteral("tableWidget_3"));

        verticalLayout_3->addWidget(tableWidget_3);


        horizontalLayout_14->addLayout(verticalLayout_3);


        verticalLayout_5->addLayout(horizontalLayout_14);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        pushButton_2 = new QPushButton(scrollAreaWidgetContents);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy);

        horizontalLayout_13->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(scrollAreaWidgetContents);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        sizePolicy.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy);

        horizontalLayout_13->addWidget(pushButton_3);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_3);


        verticalLayout_5->addLayout(horizontalLayout_13);


        horizontalLayout_22->addLayout(verticalLayout_5);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        line_4 = new QFrame(scrollAreaWidgetContents);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::VLine);
        line_4->setFrameShadow(QFrame::Sunken);

        horizontalLayout_11->addWidget(line_4);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_5 = new QLabel(scrollAreaWidgetContents);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_2->addWidget(label_5);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_6 = new QLabel(scrollAreaWidgetContents);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_3->addWidget(label_6);

        doubleSpinBox = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        sizePolicy.setHeightForWidth(doubleSpinBox->sizePolicy().hasHeightForWidth());
        doubleSpinBox->setSizePolicy(sizePolicy);

        horizontalLayout_3->addWidget(doubleSpinBox);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_7 = new QLabel(scrollAreaWidgetContents);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_4->addWidget(label_7);

        doubleSpinBox_2 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        sizePolicy.setHeightForWidth(doubleSpinBox_2->sizePolicy().hasHeightForWidth());
        doubleSpinBox_2->setSizePolicy(sizePolicy);

        horizontalLayout_4->addWidget(doubleSpinBox_2);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_8 = new QLabel(scrollAreaWidgetContents);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_5->addWidget(label_8);

        doubleSpinBox_3 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_3->setObjectName(QStringLiteral("doubleSpinBox_3"));
        sizePolicy.setHeightForWidth(doubleSpinBox_3->sizePolicy().hasHeightForWidth());
        doubleSpinBox_3->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(doubleSpinBox_3);


        verticalLayout_2->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label_9 = new QLabel(scrollAreaWidgetContents);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_6->addWidget(label_9);

        doubleSpinBox_4 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_4->setObjectName(QStringLiteral("doubleSpinBox_4"));
        sizePolicy.setHeightForWidth(doubleSpinBox_4->sizePolicy().hasHeightForWidth());
        doubleSpinBox_4->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(doubleSpinBox_4);


        verticalLayout_2->addLayout(horizontalLayout_6);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        pushButton_6 = new QPushButton(scrollAreaWidgetContents);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        sizePolicy.setHeightForWidth(pushButton_6->sizePolicy().hasHeightForWidth());
        pushButton_6->setSizePolicy(sizePolicy);

        horizontalLayout_12->addWidget(pushButton_6);

        pushButton_7 = new QPushButton(scrollAreaWidgetContents);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        sizePolicy.setHeightForWidth(pushButton_7->sizePolicy().hasHeightForWidth());
        pushButton_7->setSizePolicy(sizePolicy);

        horizontalLayout_12->addWidget(pushButton_7);


        verticalLayout_2->addLayout(horizontalLayout_12);

        line_8 = new QFrame(scrollAreaWidgetContents);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_8);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_10 = new QLabel(scrollAreaWidgetContents);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_7->addWidget(label_10);

        doubleSpinBox_5 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_5->setObjectName(QStringLiteral("doubleSpinBox_5"));
        sizePolicy.setHeightForWidth(doubleSpinBox_5->sizePolicy().hasHeightForWidth());
        doubleSpinBox_5->setSizePolicy(sizePolicy);

        horizontalLayout_7->addWidget(doubleSpinBox_5);


        verticalLayout_2->addLayout(horizontalLayout_7);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        label_23 = new QLabel(scrollAreaWidgetContents);
        label_23->setObjectName(QStringLiteral("label_23"));

        horizontalLayout_25->addWidget(label_23);

        doubleSpinBox_13 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_13->setObjectName(QStringLiteral("doubleSpinBox_13"));
        sizePolicy.setHeightForWidth(doubleSpinBox_13->sizePolicy().hasHeightForWidth());
        doubleSpinBox_13->setSizePolicy(sizePolicy);
        doubleSpinBox_13->setDecimals(5);
        doubleSpinBox_13->setMinimum(-99.99);

        horizontalLayout_25->addWidget(doubleSpinBox_13);


        verticalLayout_2->addLayout(horizontalLayout_25);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        label_24 = new QLabel(scrollAreaWidgetContents);
        label_24->setObjectName(QStringLiteral("label_24"));

        horizontalLayout_26->addWidget(label_24);

        doubleSpinBox_14 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_14->setObjectName(QStringLiteral("doubleSpinBox_14"));
        sizePolicy.setHeightForWidth(doubleSpinBox_14->sizePolicy().hasHeightForWidth());
        doubleSpinBox_14->setSizePolicy(sizePolicy);
        doubleSpinBox_14->setDecimals(5);
        doubleSpinBox_14->setMinimum(-99.99);

        horizontalLayout_26->addWidget(doubleSpinBox_14);


        verticalLayout_2->addLayout(horizontalLayout_26);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        label_25 = new QLabel(scrollAreaWidgetContents);
        label_25->setObjectName(QStringLiteral("label_25"));

        horizontalLayout_27->addWidget(label_25);

        doubleSpinBox_15 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_15->setObjectName(QStringLiteral("doubleSpinBox_15"));
        sizePolicy.setHeightForWidth(doubleSpinBox_15->sizePolicy().hasHeightForWidth());
        doubleSpinBox_15->setSizePolicy(sizePolicy);
        doubleSpinBox_15->setDecimals(5);
        doubleSpinBox_15->setMinimum(-99.99);

        horizontalLayout_27->addWidget(doubleSpinBox_15);


        verticalLayout_2->addLayout(horizontalLayout_27);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        label_26 = new QLabel(scrollAreaWidgetContents);
        label_26->setObjectName(QStringLiteral("label_26"));

        horizontalLayout_28->addWidget(label_26);

        doubleSpinBox_16 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_16->setObjectName(QStringLiteral("doubleSpinBox_16"));
        sizePolicy.setHeightForWidth(doubleSpinBox_16->sizePolicy().hasHeightForWidth());
        doubleSpinBox_16->setSizePolicy(sizePolicy);
        doubleSpinBox_16->setDecimals(5);
        doubleSpinBox_16->setMinimum(-99.99);

        horizontalLayout_28->addWidget(doubleSpinBox_16);


        verticalLayout_2->addLayout(horizontalLayout_28);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        label_27 = new QLabel(scrollAreaWidgetContents);
        label_27->setObjectName(QStringLiteral("label_27"));

        horizontalLayout_29->addWidget(label_27);

        doubleSpinBox_17 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_17->setObjectName(QStringLiteral("doubleSpinBox_17"));
        sizePolicy.setHeightForWidth(doubleSpinBox_17->sizePolicy().hasHeightForWidth());
        doubleSpinBox_17->setSizePolicy(sizePolicy);
        doubleSpinBox_17->setDecimals(5);
        doubleSpinBox_17->setMinimum(-99.99);

        horizontalLayout_29->addWidget(doubleSpinBox_17);


        verticalLayout_2->addLayout(horizontalLayout_29);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setObjectName(QStringLiteral("horizontalLayout_30"));
        label_28 = new QLabel(scrollAreaWidgetContents);
        label_28->setObjectName(QStringLiteral("label_28"));

        horizontalLayout_30->addWidget(label_28);

        doubleSpinBox_18 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_18->setObjectName(QStringLiteral("doubleSpinBox_18"));
        sizePolicy.setHeightForWidth(doubleSpinBox_18->sizePolicy().hasHeightForWidth());
        doubleSpinBox_18->setSizePolicy(sizePolicy);
        doubleSpinBox_18->setDecimals(6);
        doubleSpinBox_18->setMaximum(9999.99);

        horizontalLayout_30->addWidget(doubleSpinBox_18);


        verticalLayout_2->addLayout(horizontalLayout_30);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        label_29 = new QLabel(scrollAreaWidgetContents);
        label_29->setObjectName(QStringLiteral("label_29"));

        horizontalLayout_31->addWidget(label_29);

        doubleSpinBox_19 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_19->setObjectName(QStringLiteral("doubleSpinBox_19"));
        sizePolicy.setHeightForWidth(doubleSpinBox_19->sizePolicy().hasHeightForWidth());
        doubleSpinBox_19->setSizePolicy(sizePolicy);
        doubleSpinBox_19->setDecimals(5);
        doubleSpinBox_19->setMinimum(-3600);
        doubleSpinBox_19->setMaximum(360);

        horizontalLayout_31->addWidget(doubleSpinBox_19);


        verticalLayout_2->addLayout(horizontalLayout_31);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        pushButton_11 = new QPushButton(scrollAreaWidgetContents);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        sizePolicy.setHeightForWidth(pushButton_11->sizePolicy().hasHeightForWidth());
        pushButton_11->setSizePolicy(sizePolicy);

        horizontalLayout_32->addWidget(pushButton_11);

        pushButton_12 = new QPushButton(scrollAreaWidgetContents);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        sizePolicy.setHeightForWidth(pushButton_12->sizePolicy().hasHeightForWidth());
        pushButton_12->setSizePolicy(sizePolicy);

        horizontalLayout_32->addWidget(pushButton_12);


        verticalLayout_2->addLayout(horizontalLayout_32);

        line_5 = new QFrame(scrollAreaWidgetContents);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_5);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButton = new QPushButton(scrollAreaWidgetContents);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        sizePolicy.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(pushButton);


        verticalLayout_2->addLayout(horizontalLayout_2);


        horizontalLayout_11->addLayout(verticalLayout_2);


        horizontalLayout_22->addLayout(horizontalLayout_11);

        line_6 = new QFrame(scrollAreaWidgetContents);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::VLine);
        line_6->setFrameShadow(QFrame::Sunken);

        horizontalLayout_22->addWidget(line_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        label_14 = new QLabel(scrollAreaWidgetContents);
        label_14->setObjectName(QStringLiteral("label_14"));

        verticalLayout_7->addWidget(label_14);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        label_15 = new QLabel(scrollAreaWidgetContents);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_21->addWidget(label_15);

        doubleSpinBox_6 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_6->setObjectName(QStringLiteral("doubleSpinBox_6"));
        doubleSpinBox_6->setDecimals(5);
        doubleSpinBox_6->setMaximum(9999.99);

        horizontalLayout_21->addWidget(doubleSpinBox_6);


        verticalLayout_7->addLayout(horizontalLayout_21);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        label_21 = new QLabel(scrollAreaWidgetContents);
        label_21->setObjectName(QStringLiteral("label_21"));

        horizontalLayout_20->addWidget(label_21);

        doubleSpinBox_7 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_7->setObjectName(QStringLiteral("doubleSpinBox_7"));
        doubleSpinBox_7->setDecimals(5);
        doubleSpinBox_7->setMaximum(9.99);

        horizontalLayout_20->addWidget(doubleSpinBox_7);


        verticalLayout_7->addLayout(horizontalLayout_20);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_16 = new QLabel(scrollAreaWidgetContents);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_19->addWidget(label_16);

        doubleSpinBox_8 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_8->setObjectName(QStringLiteral("doubleSpinBox_8"));
        doubleSpinBox_8->setDecimals(5);
        doubleSpinBox_8->setMinimum(-999.99);
        doubleSpinBox_8->setMaximum(999.99);

        horizontalLayout_19->addWidget(doubleSpinBox_8);


        verticalLayout_7->addLayout(horizontalLayout_19);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        label_17 = new QLabel(scrollAreaWidgetContents);
        label_17->setObjectName(QStringLiteral("label_17"));

        horizontalLayout_18->addWidget(label_17);

        doubleSpinBox_9 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_9->setObjectName(QStringLiteral("doubleSpinBox_9"));
        doubleSpinBox_9->setDecimals(5);
        doubleSpinBox_9->setMinimum(-999.99);
        doubleSpinBox_9->setMaximum(999.99);

        horizontalLayout_18->addWidget(doubleSpinBox_9);


        verticalLayout_7->addLayout(horizontalLayout_18);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_18 = new QLabel(scrollAreaWidgetContents);
        label_18->setObjectName(QStringLiteral("label_18"));

        horizontalLayout_17->addWidget(label_18);

        doubleSpinBox_10 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_10->setObjectName(QStringLiteral("doubleSpinBox_10"));
        doubleSpinBox_10->setDecimals(5);
        doubleSpinBox_10->setMinimum(-999);
        doubleSpinBox_10->setMaximum(999.99);

        horizontalLayout_17->addWidget(doubleSpinBox_10);


        verticalLayout_7->addLayout(horizontalLayout_17);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_19 = new QLabel(scrollAreaWidgetContents);
        label_19->setObjectName(QStringLiteral("label_19"));

        horizontalLayout_16->addWidget(label_19);

        doubleSpinBox_11 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_11->setObjectName(QStringLiteral("doubleSpinBox_11"));
        doubleSpinBox_11->setDecimals(6);
        doubleSpinBox_11->setMaximum(1e+7);

        horizontalLayout_16->addWidget(doubleSpinBox_11);


        verticalLayout_7->addLayout(horizontalLayout_16);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        label_20 = new QLabel(scrollAreaWidgetContents);
        label_20->setObjectName(QStringLiteral("label_20"));

        horizontalLayout_15->addWidget(label_20);

        doubleSpinBox_12 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_12->setObjectName(QStringLiteral("doubleSpinBox_12"));
        doubleSpinBox_12->setDecimals(5);
        doubleSpinBox_12->setMinimum(-360);
        doubleSpinBox_12->setMaximum(360);

        horizontalLayout_15->addWidget(doubleSpinBox_12);


        verticalLayout_7->addLayout(horizontalLayout_15);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        pushButton_8 = new QPushButton(scrollAreaWidgetContents);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        sizePolicy.setHeightForWidth(pushButton_8->sizePolicy().hasHeightForWidth());
        pushButton_8->setSizePolicy(sizePolicy);

        horizontalLayout_23->addWidget(pushButton_8);

        pushButton_9 = new QPushButton(scrollAreaWidgetContents);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        sizePolicy.setHeightForWidth(pushButton_9->sizePolicy().hasHeightForWidth());
        pushButton_9->setSizePolicy(sizePolicy);

        horizontalLayout_23->addWidget(pushButton_9);


        verticalLayout_7->addLayout(horizontalLayout_23);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        comboBox = new QComboBox(scrollAreaWidgetContents);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBox->sizePolicy().hasHeightForWidth());
        comboBox->setSizePolicy(sizePolicy1);

        horizontalLayout_24->addWidget(comboBox);

        pushButton_10 = new QPushButton(scrollAreaWidgetContents);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        sizePolicy.setHeightForWidth(pushButton_10->sizePolicy().hasHeightForWidth());
        pushButton_10->setSizePolicy(sizePolicy);

        horizontalLayout_24->addWidget(pushButton_10);


        verticalLayout_7->addLayout(horizontalLayout_24);

        line_7 = new QFrame(scrollAreaWidgetContents);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        verticalLayout_7->addWidget(line_7);

        label_22 = new QLabel(scrollAreaWidgetContents);
        label_22->setObjectName(QStringLiteral("label_22"));

        verticalLayout_7->addWidget(label_22);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        label_30 = new QLabel(scrollAreaWidgetContents);
        label_30->setObjectName(QStringLiteral("label_30"));

        horizontalLayout_33->addWidget(label_30);

        lineEdit_3 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        sizePolicy.setHeightForWidth(lineEdit_3->sizePolicy().hasHeightForWidth());
        lineEdit_3->setSizePolicy(sizePolicy);

        horizontalLayout_33->addWidget(lineEdit_3);


        verticalLayout_7->addLayout(horizontalLayout_33);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        pushButton_5 = new QPushButton(scrollAreaWidgetContents);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        sizePolicy.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy);

        horizontalLayout_8->addWidget(pushButton_5);

        lineEdit_2 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        sizePolicy.setHeightForWidth(lineEdit_2->sizePolicy().hasHeightForWidth());
        lineEdit_2->setSizePolicy(sizePolicy);

        horizontalLayout_8->addWidget(lineEdit_2);

        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_8->addWidget(label_11);


        verticalLayout_7->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        pushButton_4 = new QPushButton(scrollAreaWidgetContents);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        sizePolicy.setHeightForWidth(pushButton_4->sizePolicy().hasHeightForWidth());
        pushButton_4->setSizePolicy(sizePolicy);

        horizontalLayout_9->addWidget(pushButton_4);

        lineEdit = new QLineEdit(scrollAreaWidgetContents);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        sizePolicy.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy);

        horizontalLayout_9->addWidget(lineEdit);

        label_12 = new QLabel(scrollAreaWidgetContents);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_9->addWidget(label_12);


        verticalLayout_7->addLayout(horizontalLayout_9);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_2);


        horizontalLayout_22->addLayout(verticalLayout_7);


        verticalLayout_6->addLayout(horizontalLayout_22);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(scrollArea, 0, 0, 1, 1);


        retranslateUi(Edit);
        QObject::connect(pushButton, SIGNAL(clicked()), Edit, SLOT(close()));

        QMetaObject::connectSlotsByName(Edit);
    } // setupUi

    void retranslateUi(QDialog *Edit)
    {
        Edit->setWindowTitle(QApplication::translate("Edit", "Dialog", Q_NULLPTR));
        label_2->setText(QApplication::translate("Edit", "Number of Spectra:", Q_NULLPTR));
        label_13->setText(QApplication::translate("Edit", "Ratio", Q_NULLPTR));
        label->setText(QApplication::translate("Edit", "Telluric Line Depths", Q_NULLPTR));
        label_3->setText(QApplication::translate("Edit", "Strength of Component A", Q_NULLPTR));
        label_4->setText(QApplication::translate("Edit", "Strength of Component B", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Edit", "Apply", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Edit", "Reset", Q_NULLPTR));
        label_5->setText(QApplication::translate("Edit", "Optimization Settings", Q_NULLPTR));
        label_6->setText(QApplication::translate("Edit", "Reflection Coef.", Q_NULLPTR));
        label_7->setText(QApplication::translate("Edit", "Contraction Coef.", Q_NULLPTR));
        label_8->setText(QApplication::translate("Edit", "Total Contraction Coef.", Q_NULLPTR));
        label_9->setText(QApplication::translate("Edit", "Expansion Coef.", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("Edit", "Apply", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("Edit", "Reset", Q_NULLPTR));
        label_10->setText(QApplication::translate("Edit", "Step Size Initial Construction:", Q_NULLPTR));
        label_23->setText(QApplication::translate("Edit", "delta P:", Q_NULLPTR));
        label_24->setText(QApplication::translate("Edit", "delta e:", Q_NULLPTR));
        label_25->setText(QApplication::translate("Edit", "delta K1:", Q_NULLPTR));
        label_26->setText(QApplication::translate("Edit", "delta K2:", Q_NULLPTR));
        label_27->setText(QApplication::translate("Edit", "delta System Vel.:", Q_NULLPTR));
        label_28->setText(QApplication::translate("Edit", "Peri. Passage:", Q_NULLPTR));
        label_29->setText(QApplication::translate("Edit", "Longitude Peri. Passage:", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("Edit", "Apply", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("Edit", "Reset", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Edit", "Close", Q_NULLPTR));
        label_14->setText(QApplication::translate("Edit", "Initial Orbit", Q_NULLPTR));
        label_15->setText(QApplication::translate("Edit", "Period P:", Q_NULLPTR));
        label_21->setText(QApplication::translate("Edit", "Eccentricity:", Q_NULLPTR));
        label_16->setText(QApplication::translate("Edit", "Amplitude K1:", Q_NULLPTR));
        label_17->setText(QApplication::translate("Edit", "Amplitude K2:", Q_NULLPTR));
        label_18->setText(QApplication::translate("Edit", "<html><head/><body><p>Systemic Velocity:</p></body></html>", Q_NULLPTR));
        label_19->setText(QApplication::translate("Edit", "Periastron Passage:", Q_NULLPTR));
        label_20->setText(QApplication::translate("Edit", "Longitude Periastron A:", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("Edit", "Apply", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("Edit", "Reset", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("Edit", "Load", Q_NULLPTR));
        label_22->setText(QApplication::translate("Edit", "Save/Load Settings", Q_NULLPTR));
        label_30->setText(QApplication::translate("Edit", "Work Path:", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("Edit", "Load", Q_NULLPTR));
        label_11->setText(QApplication::translate("Edit", ".scl", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("Edit", "Save", Q_NULLPTR));
        label_12->setText(QApplication::translate("Edit", ".scl", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Edit: public Ui_Edit {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDIT_H
