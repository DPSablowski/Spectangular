/****************************************************************************
** Meta object code from reading C++ file 'plotspec.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "plotspec.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'plotspec.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PlotSpec_t {
    QByteArrayData data[42];
    char stringdata0[859];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PlotSpec_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PlotSpec_t qt_meta_stringdata_PlotSpec = {
    {
QT_MOC_LITERAL(0, 0, 8), // "PlotSpec"
QT_MOC_LITERAL(1, 9, 6), // "seData"
QT_MOC_LITERAL(2, 16, 0), // ""
QT_MOC_LITERAL(3, 17, 3), // "str"
QT_MOC_LITERAL(4, 21, 4), // "str2"
QT_MOC_LITERAL(5, 26, 4), // "str3"
QT_MOC_LITERAL(6, 31, 4), // "str4"
QT_MOC_LITERAL(7, 36, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(8, 60, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(9, 84, 29), // "on_doubleSpinBox_valueChanged"
QT_MOC_LITERAL(10, 114, 31), // "on_doubleSpinBox_2_valueChanged"
QT_MOC_LITERAL(11, 146, 31), // "on_doubleSpinBox_3_valueChanged"
QT_MOC_LITERAL(12, 178, 31), // "on_doubleSpinBox_4_valueChanged"
QT_MOC_LITERAL(13, 210, 29), // "on_lineEdit_2_editingFinished"
QT_MOC_LITERAL(14, 240, 29), // "on_lineEdit_3_editingFinished"
QT_MOC_LITERAL(15, 270, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(16, 294, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(17, 314, 21), // "on_checkBox_2_clicked"
QT_MOC_LITERAL(18, 336, 21), // "on_checkBox_3_clicked"
QT_MOC_LITERAL(19, 358, 24), // "on_lineEdit_5_textEdited"
QT_MOC_LITERAL(20, 383, 23), // "on_spinBox_valueChanged"
QT_MOC_LITERAL(21, 407, 32), // "on_doubleSpinBox_10_valueChanged"
QT_MOC_LITERAL(22, 440, 32), // "on_doubleSpinBox_12_valueChanged"
QT_MOC_LITERAL(23, 473, 31), // "on_doubleSpinBox_9_valueChanged"
QT_MOC_LITERAL(24, 505, 32), // "on_doubleSpinBox_11_valueChanged"
QT_MOC_LITERAL(25, 538, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(26, 562, 3), // "SNR"
QT_MOC_LITERAL(27, 566, 2), // "EW"
QT_MOC_LITERAL(28, 569, 16), // "showPointToolTip"
QT_MOC_LITERAL(29, 586, 12), // "QMouseEvent*"
QT_MOC_LITERAL(30, 599, 5), // "event"
QT_MOC_LITERAL(31, 605, 11), // "writeCoords"
QT_MOC_LITERAL(32, 617, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(33, 641, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(34, 665, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(35, 689, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(36, 713, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(37, 738, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(38, 763, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(39, 788, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(40, 813, 22), // "on_checkBox_14_clicked"
QT_MOC_LITERAL(41, 836, 22) // "on_checkBox_13_clicked"

    },
    "PlotSpec\0seData\0\0str\0str2\0str3\0str4\0"
    "on_pushButton_2_clicked\0on_pushButton_3_clicked\0"
    "on_doubleSpinBox_valueChanged\0"
    "on_doubleSpinBox_2_valueChanged\0"
    "on_doubleSpinBox_3_valueChanged\0"
    "on_doubleSpinBox_4_valueChanged\0"
    "on_lineEdit_2_editingFinished\0"
    "on_lineEdit_3_editingFinished\0"
    "on_pushButton_4_clicked\0on_checkBox_clicked\0"
    "on_checkBox_2_clicked\0on_checkBox_3_clicked\0"
    "on_lineEdit_5_textEdited\0"
    "on_spinBox_valueChanged\0"
    "on_doubleSpinBox_10_valueChanged\0"
    "on_doubleSpinBox_12_valueChanged\0"
    "on_doubleSpinBox_9_valueChanged\0"
    "on_doubleSpinBox_11_valueChanged\0"
    "on_pushButton_5_clicked\0SNR\0EW\0"
    "showPointToolTip\0QMouseEvent*\0event\0"
    "writeCoords\0on_pushButton_6_clicked\0"
    "on_pushButton_7_clicked\0on_pushButton_8_clicked\0"
    "on_pushButton_9_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_11_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_13_clicked\0"
    "on_checkBox_14_clicked\0on_checkBox_13_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PlotSpec[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    4,  184,    2, 0x0a /* Public */,
       7,    0,  193,    2, 0x0a /* Public */,
       8,    0,  194,    2, 0x0a /* Public */,
       9,    0,  195,    2, 0x08 /* Private */,
      10,    0,  196,    2, 0x08 /* Private */,
      11,    0,  197,    2, 0x08 /* Private */,
      12,    0,  198,    2, 0x08 /* Private */,
      13,    0,  199,    2, 0x08 /* Private */,
      14,    0,  200,    2, 0x08 /* Private */,
      15,    0,  201,    2, 0x08 /* Private */,
      16,    0,  202,    2, 0x08 /* Private */,
      17,    0,  203,    2, 0x08 /* Private */,
      18,    0,  204,    2, 0x08 /* Private */,
      19,    0,  205,    2, 0x08 /* Private */,
      20,    0,  206,    2, 0x08 /* Private */,
      21,    0,  207,    2, 0x08 /* Private */,
      22,    0,  208,    2, 0x08 /* Private */,
      23,    0,  209,    2, 0x08 /* Private */,
      24,    0,  210,    2, 0x08 /* Private */,
      25,    0,  211,    2, 0x08 /* Private */,
      26,    0,  212,    2, 0x08 /* Private */,
      27,    0,  213,    2, 0x08 /* Private */,
      28,    1,  214,    2, 0x08 /* Private */,
      31,    1,  217,    2, 0x08 /* Private */,
      32,    0,  220,    2, 0x08 /* Private */,
      33,    0,  221,    2, 0x08 /* Private */,
      34,    0,  222,    2, 0x08 /* Private */,
      35,    0,  223,    2, 0x08 /* Private */,
      36,    0,  224,    2, 0x08 /* Private */,
      37,    0,  225,    2, 0x08 /* Private */,
      38,    0,  226,    2, 0x08 /* Private */,
      39,    0,  227,    2, 0x08 /* Private */,
      40,    0,  228,    2, 0x08 /* Private */,
      41,    0,  229,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,    3,    4,    5,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 29,   30,
    QMetaType::Void, 0x80000000 | 29,   30,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PlotSpec::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        PlotSpec *_t = static_cast<PlotSpec *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->seData((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 1: _t->on_pushButton_2_clicked(); break;
        case 2: _t->on_pushButton_3_clicked(); break;
        case 3: _t->on_doubleSpinBox_valueChanged(); break;
        case 4: _t->on_doubleSpinBox_2_valueChanged(); break;
        case 5: _t->on_doubleSpinBox_3_valueChanged(); break;
        case 6: _t->on_doubleSpinBox_4_valueChanged(); break;
        case 7: _t->on_lineEdit_2_editingFinished(); break;
        case 8: _t->on_lineEdit_3_editingFinished(); break;
        case 9: _t->on_pushButton_4_clicked(); break;
        case 10: _t->on_checkBox_clicked(); break;
        case 11: _t->on_checkBox_2_clicked(); break;
        case 12: _t->on_checkBox_3_clicked(); break;
        case 13: _t->on_lineEdit_5_textEdited(); break;
        case 14: _t->on_spinBox_valueChanged(); break;
        case 15: _t->on_doubleSpinBox_10_valueChanged(); break;
        case 16: _t->on_doubleSpinBox_12_valueChanged(); break;
        case 17: _t->on_doubleSpinBox_9_valueChanged(); break;
        case 18: _t->on_doubleSpinBox_11_valueChanged(); break;
        case 19: _t->on_pushButton_5_clicked(); break;
        case 20: _t->SNR(); break;
        case 21: _t->EW(); break;
        case 22: _t->showPointToolTip((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 23: _t->writeCoords((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 24: _t->on_pushButton_6_clicked(); break;
        case 25: _t->on_pushButton_7_clicked(); break;
        case 26: _t->on_pushButton_8_clicked(); break;
        case 27: _t->on_pushButton_9_clicked(); break;
        case 28: _t->on_pushButton_10_clicked(); break;
        case 29: _t->on_pushButton_11_clicked(); break;
        case 30: _t->on_pushButton_12_clicked(); break;
        case 31: _t->on_pushButton_13_clicked(); break;
        case 32: _t->on_checkBox_14_clicked(); break;
        case 33: _t->on_checkBox_13_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject PlotSpec::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_PlotSpec.data,
      qt_meta_data_PlotSpec,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *PlotSpec::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PlotSpec::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_PlotSpec.stringdata0))
        return static_cast<void*>(const_cast< PlotSpec*>(this));
    return QDialog::qt_metacast(_clname);
}

int PlotSpec::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 34;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
