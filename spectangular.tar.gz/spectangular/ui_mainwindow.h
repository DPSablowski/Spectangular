/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSpectrum_Plotter;
    QAction *actionAbout;
    QAction *actionBug_Report;
    QAction *actionCorrelation;
    QAction *actionEditor;
    QAction *actionArithmetic;
    QAction *actionManual;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_13;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_4;
    QLabel *label_10;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout;
    QCheckBox *checkBox;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QSpinBox *spinBox;
    QLabel *label_3;
    QSpinBox *spinBox_2;
    QCheckBox *checkBox_27;
    QCheckBox *checkBox_13;
    QSpacerItem *horizontalSpacer_17;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *checkBox_2;
    QLineEdit *lineEdit_2;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_26;
    QCheckBox *checkBox_16;
    QLineEdit *lineEdit_18;
    QLabel *label_34;
    QCheckBox *checkBox_18;
    QCheckBox *checkBox_17;
    QCheckBox *checkBox_35;
    QSpacerItem *horizontalSpacer_22;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_7;
    QLineEdit *lineEdit_3;
    QSpinBox *spinBox_9;
    QLabel *label_9;
    QSpinBox *spinBox_10;
    QLabel *label_12;
    QLineEdit *lineEdit_19;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_22;
    QDoubleSpinBox *doubleSpinBox_4;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_17;
    QComboBox *comboBox;
    QLabel *label_16;
    QLineEdit *lineEdit_9;
    QSpacerItem *horizontalSpacer_12;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_17;
    QLineEdit *lineEdit_11;
    QLabel *label_20;
    QLineEdit *lineEdit_12;
    QSpacerItem *horizontalSpacer_18;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_11;
    QLineEdit *lineEdit_4;
    QSpacerItem *horizontalSpacer_6;
    QHBoxLayout *horizontalLayout_15;
    QPushButton *pushButton_2;
    QCheckBox *checkBox_7;
    QCheckBox *checkBox_8;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_34;
    QSpacerItem *horizontalSpacer_13;
    QHBoxLayout *horizontalLayout_11;
    QPushButton *pushButton_5;
    QCheckBox *checkBox_5;
    QCheckBox *checkBox_6;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_11;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *pushButton_12;
    QCheckBox *checkBox_20;
    QCheckBox *checkBox_21;
    QLineEdit *lineEdit_27;
    QCheckBox *checkBox_24;
    QCheckBox *checkBox_25;
    QCheckBox *checkBox_26;
    QLineEdit *lineEdit_28;
    QSpacerItem *horizontalSpacer_10;
    QSpacerItem *verticalSpacer_2;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBox;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_6;
    QDoubleSpinBox *doubleSpinBox_2;
    QPlainTextEdit *plainTextEdit;
    QFrame *line;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_19;
    QPushButton *pushButton_4;
    QLabel *label;
    QSpinBox *spinBox_3;
    QCheckBox *checkBox_9;
    QCheckBox *checkBox_11;
    QCheckBox *checkBox_12;
    QCheckBox *checkBox_32;
    QCheckBox *checkBox_23;
    QPushButton *pushButton_7;
    QSpacerItem *horizontalSpacer_15;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_18;
    QSpinBox *spinBox_4;
    QLabel *label_21;
    QSpinBox *spinBox_5;
    QLabel *label_25;
    QCheckBox *checkBox_14;
    QCheckBox *checkBox_15;
    QLabel *label_28;
    QSpinBox *spinBox_7;
    QLabel *label_29;
    QSpinBox *spinBox_8;
    QSpacerItem *horizontalSpacer_14;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_32;
    QLineEdit *lineEdit_25;
    QLabel *label_33;
    QLineEdit *lineEdit_26;
    QPushButton *pushButton_11;
    QSpacerItem *horizontalSpacer_20;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_23;
    QLineEdit *lineEdit_5;
    QLabel *label_24;
    QLineEdit *lineEdit_8;
    QLabel *label_45;
    QLineEdit *lineEdit_20;
    QSpacerItem *horizontalSpacer_7;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_26;
    QLineEdit *lineEdit_10;
    QLabel *label_27;
    QLineEdit *lineEdit_13;
    QLabel *label_46;
    QLineEdit *lineEdit_21;
    QSpacerItem *horizontalSpacer_19;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_30;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QLabel *label_31;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_17;
    QSpacerItem *horizontalSpacer_21;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_15;
    QLineEdit *lineEdit_6;
    QLabel *label_14;
    QLineEdit *lineEdit_7;
    QLabel *label_19;
    QDoubleSpinBox *doubleSpinBox_3;
    QSpacerItem *horizontalSpacer_9;
    QHBoxLayout *horizontalLayout_36;
    QPushButton *pushButton_9;
    QLineEdit *lineEdit_22;
    QLabel *label_48;
    QPushButton *pushButton_10;
    QLineEdit *lineEdit_23;
    QLabel *label_49;
    QSpacerItem *horizontalSpacer_25;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout_28;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_27;
    QPushButton *pushButton_8;
    QLineEdit *lineEdit_24;
    QSpacerItem *horizontalSpacer_8;
    QPlainTextEdit *plainTextEdit_2;
    QCustomPlot *customPlot_4;
    QHBoxLayout *horizontalLayout_14;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer_3;
    QFrame *line_3;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_8;
    QCustomPlot *customPlot;
    QCheckBox *checkBox_22;
    QCustomPlot *customPlot_2;
    QHBoxLayout *horizontalLayout_21;
    QLabel *label_13;
    QDoubleSpinBox *doubleSpinBox_5;
    QSpacerItem *horizontalSpacer_23;
    QCustomPlot *customPlot_3;
    QHBoxLayout *horizontalLayout_20;
    QPushButton *pushButton_6;
    QCheckBox *checkBox_10;
    QSpinBox *spinBox_6;
    QCheckBox *checkBox_33;
    QDoubleSpinBox *doubleSpinBox_14;
    QLabel *label_47;
    QDoubleSpinBox *doubleSpinBox_15;
    QCheckBox *checkBox_19;
    QSpacerItem *horizontalSpacer_16;
    QMenuBar *menuBar;
    QMenu *menuTools;
    QMenu *menuHelp;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(2307, 1354);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(255, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Light, brush1);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush1);
        QBrush brush2(QColor(127, 127, 127, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush2);
        QBrush brush3(QColor(170, 170, 170, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        QBrush brush4(QColor(255, 255, 220, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        MainWindow->setPalette(palette);
        QFont font;
        font.setFamily(QStringLiteral("Bitstream Charter"));
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        MainWindow->setFont(font);
        QIcon icon;
        icon.addFile(QStringLiteral(":/new/background/Binary.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        actionSpectrum_Plotter = new QAction(MainWindow);
        actionSpectrum_Plotter->setObjectName(QStringLiteral("actionSpectrum_Plotter"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/new/Icons/SPlotter.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSpectrum_Plotter->setIcon(icon1);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionBug_Report = new QAction(MainWindow);
        actionBug_Report->setObjectName(QStringLiteral("actionBug_Report"));
        actionCorrelation = new QAction(MainWindow);
        actionCorrelation->setObjectName(QStringLiteral("actionCorrelation"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/new/Icons/Corr.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCorrelation->setIcon(icon2);
        actionEditor = new QAction(MainWindow);
        actionEditor->setObjectName(QStringLiteral("actionEditor"));
        actionArithmetic = new QAction(MainWindow);
        actionArithmetic->setObjectName(QStringLiteral("actionArithmetic"));
        actionManual = new QAction(MainWindow);
        actionManual->setObjectName(QStringLiteral("actionManual"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        scrollArea = new QScrollArea(centralWidget);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setFont(font);
        scrollArea->setAutoFillBackground(false);
        scrollArea->setStyleSheet(QStringLiteral(""));
        scrollArea->setFrameShadow(QFrame::Sunken);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, -27, 2396, 1317));
        gridLayout_2 = new QGridLayout(scrollAreaWidgetContents);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_4 = new QLabel(scrollAreaWidgetContents);
        label_4->setObjectName(QStringLiteral("label_4"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy);
        label_4->setPixmap(QPixmap(QString::fromUtf8(":/new/Icons/AIP.jpeg")));

        horizontalLayout_5->addWidget(label_4);

        label_10 = new QLabel(scrollAreaWidgetContents);
        label_10->setObjectName(QStringLiteral("label_10"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_10->sizePolicy().hasHeightForWidth());
        label_10->setSizePolicy(sizePolicy1);
        label_10->setPixmap(QPixmap(QString::fromUtf8(":/new/Icons/activity_logo.png")));

        horizontalLayout_5->addWidget(label_10);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);


        verticalLayout_4->addLayout(horizontalLayout_5);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        checkBox = new QCheckBox(scrollAreaWidgetContents);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(checkBox->sizePolicy().hasHeightForWidth());
        checkBox->setSizePolicy(sizePolicy2);
        checkBox->setFont(font);

        horizontalLayout->addWidget(checkBox);

        lineEdit = new QLineEdit(scrollAreaWidgetContents);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        sizePolicy1.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy1);
        QPalette palette1;
        QBrush brush5(QColor(255, 0, 0, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette1.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette1.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette1.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit->setPalette(palette1);
        lineEdit->setFont(font);
        lineEdit->setAutoFillBackground(false);

        horizontalLayout->addWidget(lineEdit);

        label_2 = new QLabel(scrollAreaWidgetContents);
        label_2->setObjectName(QStringLiteral("label_2"));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::Text, brush);
        palette2.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette2.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        label_2->setPalette(palette2);
        label_2->setFont(font);

        horizontalLayout->addWidget(label_2);

        spinBox = new QSpinBox(scrollAreaWidgetContents);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        sizePolicy1.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
        spinBox->setSizePolicy(sizePolicy1);
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::Text, brush);
        palette3.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette3.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        spinBox->setPalette(palette3);

        horizontalLayout->addWidget(spinBox);

        label_3 = new QLabel(scrollAreaWidgetContents);
        label_3->setObjectName(QStringLiteral("label_3"));
        sizePolicy.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy);
        label_3->setFont(font);

        horizontalLayout->addWidget(label_3);

        spinBox_2 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_2->setObjectName(QStringLiteral("spinBox_2"));
        sizePolicy1.setHeightForWidth(spinBox_2->sizePolicy().hasHeightForWidth());
        spinBox_2->setSizePolicy(sizePolicy1);
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::Text, brush);
        palette4.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette4.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        spinBox_2->setPalette(palette4);
        spinBox_2->setMaximum(999);
        spinBox_2->setValue(1);

        horizontalLayout->addWidget(spinBox_2);

        checkBox_27 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_27->setObjectName(QStringLiteral("checkBox_27"));

        horizontalLayout->addWidget(checkBox_27);

        checkBox_13 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_13->setObjectName(QStringLiteral("checkBox_13"));
        QFont font1;
        font1.setFamily(QStringLiteral("Bitstream Charter"));
        font1.setBold(true);
        font1.setItalic(true);
        font1.setUnderline(false);
        font1.setWeight(75);
        checkBox_13->setFont(font1);

        horizontalLayout->addWidget(checkBox_13);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_17);


        verticalLayout_4->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        checkBox_2 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        sizePolicy2.setHeightForWidth(checkBox_2->sizePolicy().hasHeightForWidth());
        checkBox_2->setSizePolicy(sizePolicy2);
        checkBox_2->setFont(font);

        horizontalLayout_2->addWidget(checkBox_2);

        lineEdit_2 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        sizePolicy1.setHeightForWidth(lineEdit_2->sizePolicy().hasHeightForWidth());
        lineEdit_2->setSizePolicy(sizePolicy1);
        QPalette palette5;
        palette5.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette5.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette5.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette5.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette5.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette5.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette5.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette5.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette5.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_2->setPalette(palette5);
        lineEdit_2->setFont(font);

        horizontalLayout_2->addWidget(lineEdit_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        verticalLayout_4->addLayout(horizontalLayout_2);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        checkBox_16 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_16->setObjectName(QStringLiteral("checkBox_16"));
        sizePolicy2.setHeightForWidth(checkBox_16->sizePolicy().hasHeightForWidth());
        checkBox_16->setSizePolicy(sizePolicy2);

        horizontalLayout_26->addWidget(checkBox_16);

        lineEdit_18 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_18->setObjectName(QStringLiteral("lineEdit_18"));
        sizePolicy1.setHeightForWidth(lineEdit_18->sizePolicy().hasHeightForWidth());
        lineEdit_18->setSizePolicy(sizePolicy1);

        horizontalLayout_26->addWidget(lineEdit_18);

        label_34 = new QLabel(scrollAreaWidgetContents);
        label_34->setObjectName(QStringLiteral("label_34"));

        horizontalLayout_26->addWidget(label_34);

        checkBox_18 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_18->setObjectName(QStringLiteral("checkBox_18"));
        checkBox_18->setEnabled(true);

        horizontalLayout_26->addWidget(checkBox_18);

        checkBox_17 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_17->setObjectName(QStringLiteral("checkBox_17"));
        checkBox_17->setEnabled(true);

        horizontalLayout_26->addWidget(checkBox_17);

        checkBox_35 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_35->setObjectName(QStringLiteral("checkBox_35"));
        checkBox_35->setEnabled(true);

        horizontalLayout_26->addWidget(checkBox_35);

        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_26->addItem(horizontalSpacer_22);


        verticalLayout_4->addLayout(horizontalLayout_26);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_7 = new QLabel(scrollAreaWidgetContents);
        label_7->setObjectName(QStringLiteral("label_7"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy3);
        label_7->setFont(font);

        horizontalLayout_7->addWidget(label_7);

        lineEdit_3 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        sizePolicy1.setHeightForWidth(lineEdit_3->sizePolicy().hasHeightForWidth());
        lineEdit_3->setSizePolicy(sizePolicy1);
        QPalette palette6;
        palette6.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette6.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette6.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette6.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette6.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette6.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette6.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette6.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette6.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_3->setPalette(palette6);
        lineEdit_3->setFont(font);

        horizontalLayout_7->addWidget(lineEdit_3);

        spinBox_9 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_9->setObjectName(QStringLiteral("spinBox_9"));

        horizontalLayout_7->addWidget(spinBox_9);

        label_9 = new QLabel(scrollAreaWidgetContents);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_7->addWidget(label_9);

        spinBox_10 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_10->setObjectName(QStringLiteral("spinBox_10"));
        spinBox_10->setMaximum(999);

        horizontalLayout_7->addWidget(spinBox_10);

        label_12 = new QLabel(scrollAreaWidgetContents);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_7->addWidget(label_12);

        lineEdit_19 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_19->setObjectName(QStringLiteral("lineEdit_19"));
        sizePolicy1.setHeightForWidth(lineEdit_19->sizePolicy().hasHeightForWidth());
        lineEdit_19->setSizePolicy(sizePolicy1);

        horizontalLayout_7->addWidget(lineEdit_19);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_4);


        verticalLayout_4->addLayout(horizontalLayout_7);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        label_22 = new QLabel(scrollAreaWidgetContents);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setFont(font);

        horizontalLayout_22->addWidget(label_22);

        doubleSpinBox_4 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_4->setObjectName(QStringLiteral("doubleSpinBox_4"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_4->sizePolicy().hasHeightForWidth());
        doubleSpinBox_4->setSizePolicy(sizePolicy1);
        QPalette palette7;
        palette7.setBrush(QPalette::Active, QPalette::Text, brush);
        palette7.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette7.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette7.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette7.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette7.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        doubleSpinBox_4->setPalette(palette7);
        doubleSpinBox_4->setDecimals(5);
        doubleSpinBox_4->setSingleStep(0.02);

        horizontalLayout_22->addWidget(doubleSpinBox_4);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_5);


        verticalLayout_4->addLayout(horizontalLayout_22);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        comboBox = new QComboBox(scrollAreaWidgetContents);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        sizePolicy1.setHeightForWidth(comboBox->sizePolicy().hasHeightForWidth());
        comboBox->setSizePolicy(sizePolicy1);
        comboBox->setMinimumSize(QSize(75, 0));
        QPalette palette8;
        palette8.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush6(QColor(243, 243, 243, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette8.setBrush(QPalette::Active, QPalette::Button, brush6);
        palette8.setBrush(QPalette::Active, QPalette::Light, brush1);
        QBrush brush7(QColor(249, 249, 249, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette8.setBrush(QPalette::Active, QPalette::Midlight, brush7);
        QBrush brush8(QColor(121, 121, 121, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette8.setBrush(QPalette::Active, QPalette::Dark, brush8);
        QBrush brush9(QColor(162, 162, 162, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette8.setBrush(QPalette::Active, QPalette::Mid, brush9);
        palette8.setBrush(QPalette::Active, QPalette::Text, brush);
        palette8.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette8.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette8.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette8.setBrush(QPalette::Active, QPalette::Window, brush6);
        palette8.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette8.setBrush(QPalette::Active, QPalette::AlternateBase, brush7);
        palette8.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette8.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::Button, brush6);
        palette8.setBrush(QPalette::Inactive, QPalette::Light, brush1);
        palette8.setBrush(QPalette::Inactive, QPalette::Midlight, brush7);
        palette8.setBrush(QPalette::Inactive, QPalette::Dark, brush8);
        palette8.setBrush(QPalette::Inactive, QPalette::Mid, brush9);
        palette8.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette8.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette8.setBrush(QPalette::Inactive, QPalette::Window, brush6);
        palette8.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette8.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush7);
        palette8.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette8.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::WindowText, brush8);
        palette8.setBrush(QPalette::Disabled, QPalette::Button, brush6);
        palette8.setBrush(QPalette::Disabled, QPalette::Light, brush1);
        palette8.setBrush(QPalette::Disabled, QPalette::Midlight, brush7);
        palette8.setBrush(QPalette::Disabled, QPalette::Dark, brush8);
        palette8.setBrush(QPalette::Disabled, QPalette::Mid, brush9);
        palette8.setBrush(QPalette::Disabled, QPalette::Text, brush8);
        palette8.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette8.setBrush(QPalette::Disabled, QPalette::ButtonText, brush8);
        palette8.setBrush(QPalette::Disabled, QPalette::Base, brush6);
        palette8.setBrush(QPalette::Disabled, QPalette::Window, brush6);
        palette8.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette8.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush6);
        palette8.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette8.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        comboBox->setPalette(palette8);

        horizontalLayout_17->addWidget(comboBox);

        label_16 = new QLabel(scrollAreaWidgetContents);
        label_16->setObjectName(QStringLiteral("label_16"));
        sizePolicy3.setHeightForWidth(label_16->sizePolicy().hasHeightForWidth());
        label_16->setSizePolicy(sizePolicy3);
        label_16->setFont(font);

        horizontalLayout_17->addWidget(label_16);

        lineEdit_9 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_9->setObjectName(QStringLiteral("lineEdit_9"));
        sizePolicy1.setHeightForWidth(lineEdit_9->sizePolicy().hasHeightForWidth());
        lineEdit_9->setSizePolicy(sizePolicy1);
        QPalette palette9;
        palette9.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette9.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette9.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette9.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette9.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette9.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette9.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette9.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette9.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette9.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette9.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette9.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_9->setPalette(palette9);
        lineEdit_9->setFont(font);

        horizontalLayout_17->addWidget(lineEdit_9);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_12);


        verticalLayout_4->addLayout(horizontalLayout_17);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        label_17 = new QLabel(scrollAreaWidgetContents);
        label_17->setObjectName(QStringLiteral("label_17"));
        sizePolicy.setHeightForWidth(label_17->sizePolicy().hasHeightForWidth());
        label_17->setSizePolicy(sizePolicy);
        label_17->setFont(font);

        horizontalLayout_18->addWidget(label_17);

        lineEdit_11 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));
        sizePolicy1.setHeightForWidth(lineEdit_11->sizePolicy().hasHeightForWidth());
        lineEdit_11->setSizePolicy(sizePolicy1);
        QPalette palette10;
        palette10.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette10.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette10.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette10.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette10.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette10.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette10.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette10.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette10.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette10.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette10.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette10.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_11->setPalette(palette10);
        lineEdit_11->setFont(font);

        horizontalLayout_18->addWidget(lineEdit_11);

        label_20 = new QLabel(scrollAreaWidgetContents);
        label_20->setObjectName(QStringLiteral("label_20"));
        sizePolicy.setHeightForWidth(label_20->sizePolicy().hasHeightForWidth());
        label_20->setSizePolicy(sizePolicy);
        label_20->setFont(font);

        horizontalLayout_18->addWidget(label_20);

        lineEdit_12 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_12->setObjectName(QStringLiteral("lineEdit_12"));
        sizePolicy1.setHeightForWidth(lineEdit_12->sizePolicy().hasHeightForWidth());
        lineEdit_12->setSizePolicy(sizePolicy1);
        QPalette palette11;
        palette11.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette11.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette11.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette11.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette11.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette11.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette11.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette11.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette11.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette11.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette11.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette11.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_12->setPalette(palette11);
        lineEdit_12->setFont(font);

        horizontalLayout_18->addWidget(lineEdit_12);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_18);


        verticalLayout_4->addLayout(horizontalLayout_18);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QStringLiteral("label_11"));
        sizePolicy3.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy3);
        label_11->setFont(font);

        horizontalLayout_10->addWidget(label_11);

        lineEdit_4 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        sizePolicy1.setHeightForWidth(lineEdit_4->sizePolicy().hasHeightForWidth());
        lineEdit_4->setSizePolicy(sizePolicy1);
        QPalette palette12;
        palette12.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette12.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette12.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette12.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette12.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette12.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette12.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette12.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette12.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette12.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette12.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette12.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_4->setPalette(palette12);
        lineEdit_4->setFont(font);

        horizontalLayout_10->addWidget(lineEdit_4);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_6);


        verticalLayout_4->addLayout(horizontalLayout_10);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        pushButton_2 = new QPushButton(scrollAreaWidgetContents);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy1.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy1);
        QPalette palette13;
        palette13.setBrush(QPalette::Active, QPalette::Text, brush);
        palette13.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette13.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette13.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette13.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette13.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        pushButton_2->setPalette(palette13);
        pushButton_2->setFont(font);

        horizontalLayout_15->addWidget(pushButton_2);

        checkBox_7 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_7->setObjectName(QStringLiteral("checkBox_7"));
        sizePolicy1.setHeightForWidth(checkBox_7->sizePolicy().hasHeightForWidth());
        checkBox_7->setSizePolicy(sizePolicy1);
        checkBox_7->setFont(font);

        horizontalLayout_15->addWidget(checkBox_7);

        checkBox_8 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_8->setObjectName(QStringLiteral("checkBox_8"));
        checkBox_8->setFont(font);

        horizontalLayout_15->addWidget(checkBox_8);

        checkBox_3 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));
        checkBox_3->setEnabled(true);
        checkBox_3->setFont(font);

        horizontalLayout_15->addWidget(checkBox_3);

        checkBox_4 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));
        checkBox_4->setEnabled(true);
        checkBox_4->setFont(font);

        horizontalLayout_15->addWidget(checkBox_4);

        checkBox_34 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_34->setObjectName(QStringLiteral("checkBox_34"));
        checkBox_34->setEnabled(false);

        horizontalLayout_15->addWidget(checkBox_34);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_13);


        verticalLayout_4->addLayout(horizontalLayout_15);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        pushButton_5 = new QPushButton(scrollAreaWidgetContents);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        sizePolicy1.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy1);
        QPalette palette14;
        palette14.setBrush(QPalette::Active, QPalette::Text, brush);
        palette14.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette14.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette14.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette14.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette14.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        pushButton_5->setPalette(palette14);
        pushButton_5->setFont(font);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/new/Icons/run.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon3);

        horizontalLayout_11->addWidget(pushButton_5);

        checkBox_5 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_5->setObjectName(QStringLiteral("checkBox_5"));
        checkBox_5->setFont(font);

        horizontalLayout_11->addWidget(checkBox_5);

        checkBox_6 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_6->setObjectName(QStringLiteral("checkBox_6"));
        checkBox_6->setFont(font);

        horizontalLayout_11->addWidget(checkBox_6);

        pushButton_3 = new QPushButton(scrollAreaWidgetContents);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        sizePolicy1.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy1);
        QPalette palette15;
        palette15.setBrush(QPalette::Active, QPalette::Text, brush);
        palette15.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette15.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette15.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette15.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette15.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        pushButton_3->setPalette(palette15);
        pushButton_3->setFont(font);
        pushButton_3->setIcon(icon3);

        horizontalLayout_11->addWidget(pushButton_3);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_11);


        verticalLayout_4->addLayout(horizontalLayout_11);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        pushButton_12 = new QPushButton(scrollAreaWidgetContents);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));

        horizontalLayout_9->addWidget(pushButton_12);

        checkBox_20 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_20->setObjectName(QStringLiteral("checkBox_20"));
        sizePolicy1.setHeightForWidth(checkBox_20->sizePolicy().hasHeightForWidth());
        checkBox_20->setSizePolicy(sizePolicy1);

        horizontalLayout_9->addWidget(checkBox_20);

        checkBox_21 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_21->setObjectName(QStringLiteral("checkBox_21"));
        sizePolicy1.setHeightForWidth(checkBox_21->sizePolicy().hasHeightForWidth());
        checkBox_21->setSizePolicy(sizePolicy1);

        horizontalLayout_9->addWidget(checkBox_21);

        lineEdit_27 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_27->setObjectName(QStringLiteral("lineEdit_27"));
        sizePolicy1.setHeightForWidth(lineEdit_27->sizePolicy().hasHeightForWidth());
        lineEdit_27->setSizePolicy(sizePolicy1);

        horizontalLayout_9->addWidget(lineEdit_27);

        checkBox_24 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_24->setObjectName(QStringLiteral("checkBox_24"));

        horizontalLayout_9->addWidget(checkBox_24);

        checkBox_25 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_25->setObjectName(QStringLiteral("checkBox_25"));

        horizontalLayout_9->addWidget(checkBox_25);

        checkBox_26 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_26->setObjectName(QStringLiteral("checkBox_26"));

        horizontalLayout_9->addWidget(checkBox_26);

        lineEdit_28 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_28->setObjectName(QStringLiteral("lineEdit_28"));

        horizontalLayout_9->addWidget(lineEdit_28);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_10);


        verticalLayout_4->addLayout(horizontalLayout_9);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);


        horizontalLayout_13->addLayout(verticalLayout_4);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_5 = new QLabel(scrollAreaWidgetContents);
        label_5->setObjectName(QStringLiteral("label_5"));
        QSizePolicy sizePolicy4(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy4);
        label_5->setFont(font);

        horizontalLayout_3->addWidget(label_5);

        doubleSpinBox = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        doubleSpinBox->setEnabled(false);
        sizePolicy1.setHeightForWidth(doubleSpinBox->sizePolicy().hasHeightForWidth());
        doubleSpinBox->setSizePolicy(sizePolicy1);
        QPalette palette16;
        palette16.setBrush(QPalette::Active, QPalette::Text, brush);
        palette16.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette16.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette16.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette16.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette16.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        doubleSpinBox->setPalette(palette16);
        doubleSpinBox->setMinimum(-999);
        doubleSpinBox->setMaximum(999);

        horizontalLayout_3->addWidget(doubleSpinBox);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_6 = new QLabel(scrollAreaWidgetContents);
        label_6->setObjectName(QStringLiteral("label_6"));
        sizePolicy4.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy4);
        label_6->setFont(font);

        horizontalLayout_4->addWidget(label_6);

        doubleSpinBox_2 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        doubleSpinBox_2->setEnabled(false);
        sizePolicy1.setHeightForWidth(doubleSpinBox_2->sizePolicy().hasHeightForWidth());
        doubleSpinBox_2->setSizePolicy(sizePolicy1);
        QPalette palette17;
        palette17.setBrush(QPalette::Active, QPalette::Text, brush);
        palette17.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette17.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette17.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette17.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette17.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        doubleSpinBox_2->setPalette(palette17);
        doubleSpinBox_2->setMinimum(-999);
        doubleSpinBox_2->setMaximum(999.99);

        horizontalLayout_4->addWidget(doubleSpinBox_2);


        verticalLayout->addLayout(horizontalLayout_4);


        verticalLayout_3->addLayout(verticalLayout);

        plainTextEdit = new QPlainTextEdit(scrollAreaWidgetContents);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        plainTextEdit->setEnabled(true);
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(plainTextEdit->sizePolicy().hasHeightForWidth());
        plainTextEdit->setSizePolicy(sizePolicy5);
        QPalette palette18;
        palette18.setBrush(QPalette::Active, QPalette::Text, brush);
        palette18.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette18.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette18.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette18.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette18.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        plainTextEdit->setPalette(palette18);
        plainTextEdit->setFont(font);
        plainTextEdit->setFrameShadow(QFrame::Plain);

        verticalLayout_3->addWidget(plainTextEdit);


        horizontalLayout_13->addLayout(verticalLayout_3);


        verticalLayout_6->addLayout(horizontalLayout_13);

        line = new QFrame(scrollAreaWidgetContents);
        line->setObjectName(QStringLiteral("line"));
        sizePolicy2.setHeightForWidth(line->sizePolicy().hasHeightForWidth());
        line->setSizePolicy(sizePolicy2);
        QPalette palette19;
        palette19.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush10(QColor(0, 49, 254, 255));
        brush10.setStyle(Qt::SolidPattern);
        palette19.setBrush(QPalette::Active, QPalette::Button, brush10);
        QBrush brush11(QColor(126, 151, 255, 255));
        brush11.setStyle(Qt::SolidPattern);
        palette19.setBrush(QPalette::Active, QPalette::Light, brush11);
        QBrush brush12(QColor(63, 100, 254, 255));
        brush12.setStyle(Qt::SolidPattern);
        palette19.setBrush(QPalette::Active, QPalette::Midlight, brush12);
        QBrush brush13(QColor(0, 24, 127, 255));
        brush13.setStyle(Qt::SolidPattern);
        palette19.setBrush(QPalette::Active, QPalette::Dark, brush13);
        QBrush brush14(QColor(0, 32, 169, 255));
        brush14.setStyle(Qt::SolidPattern);
        palette19.setBrush(QPalette::Active, QPalette::Mid, brush14);
        palette19.setBrush(QPalette::Active, QPalette::Text, brush);
        palette19.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette19.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette19.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette19.setBrush(QPalette::Active, QPalette::Window, brush10);
        palette19.setBrush(QPalette::Active, QPalette::Shadow, brush);
        QBrush brush15(QColor(127, 152, 254, 255));
        brush15.setStyle(Qt::SolidPattern);
        palette19.setBrush(QPalette::Active, QPalette::AlternateBase, brush15);
        palette19.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette19.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette19.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette19.setBrush(QPalette::Inactive, QPalette::Button, brush10);
        palette19.setBrush(QPalette::Inactive, QPalette::Light, brush11);
        palette19.setBrush(QPalette::Inactive, QPalette::Midlight, brush12);
        palette19.setBrush(QPalette::Inactive, QPalette::Dark, brush13);
        palette19.setBrush(QPalette::Inactive, QPalette::Mid, brush14);
        palette19.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette19.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette19.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette19.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette19.setBrush(QPalette::Inactive, QPalette::Window, brush10);
        palette19.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette19.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush15);
        palette19.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette19.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette19.setBrush(QPalette::Disabled, QPalette::WindowText, brush13);
        palette19.setBrush(QPalette::Disabled, QPalette::Button, brush10);
        palette19.setBrush(QPalette::Disabled, QPalette::Light, brush11);
        palette19.setBrush(QPalette::Disabled, QPalette::Midlight, brush12);
        palette19.setBrush(QPalette::Disabled, QPalette::Dark, brush13);
        palette19.setBrush(QPalette::Disabled, QPalette::Mid, brush14);
        palette19.setBrush(QPalette::Disabled, QPalette::Text, brush13);
        palette19.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette19.setBrush(QPalette::Disabled, QPalette::ButtonText, brush13);
        palette19.setBrush(QPalette::Disabled, QPalette::Base, brush10);
        palette19.setBrush(QPalette::Disabled, QPalette::Window, brush10);
        palette19.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette19.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush10);
        palette19.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette19.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        line->setPalette(palette19);
        line->setLineWidth(2);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_6->addWidget(line);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        pushButton_4 = new QPushButton(scrollAreaWidgetContents);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        sizePolicy1.setHeightForWidth(pushButton_4->sizePolicy().hasHeightForWidth());
        pushButton_4->setSizePolicy(sizePolicy1);
        QPalette palette20;
        palette20.setBrush(QPalette::Active, QPalette::Text, brush);
        palette20.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette20.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette20.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette20.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette20.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        pushButton_4->setPalette(palette20);
        pushButton_4->setFont(font);
        pushButton_4->setIcon(icon3);

        horizontalLayout_19->addWidget(pushButton_4);

        label = new QLabel(scrollAreaWidgetContents);
        label->setObjectName(QStringLiteral("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setFont(font);

        horizontalLayout_19->addWidget(label);

        spinBox_3 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_3->setObjectName(QStringLiteral("spinBox_3"));
        sizePolicy1.setHeightForWidth(spinBox_3->sizePolicy().hasHeightForWidth());
        spinBox_3->setSizePolicy(sizePolicy1);
        QPalette palette21;
        palette21.setBrush(QPalette::Active, QPalette::Text, brush);
        palette21.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette21.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette21.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette21.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette21.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        spinBox_3->setPalette(palette21);
        spinBox_3->setMaximum(9999);
        spinBox_3->setValue(3);

        horizontalLayout_19->addWidget(spinBox_3);

        checkBox_9 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_9->setObjectName(QStringLiteral("checkBox_9"));
        sizePolicy1.setHeightForWidth(checkBox_9->sizePolicy().hasHeightForWidth());
        checkBox_9->setSizePolicy(sizePolicy1);
        checkBox_9->setFont(font);

        horizontalLayout_19->addWidget(checkBox_9);

        checkBox_11 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_11->setObjectName(QStringLiteral("checkBox_11"));
        sizePolicy1.setHeightForWidth(checkBox_11->sizePolicy().hasHeightForWidth());
        checkBox_11->setSizePolicy(sizePolicy1);
        checkBox_11->setFont(font);

        horizontalLayout_19->addWidget(checkBox_11);

        checkBox_12 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_12->setObjectName(QStringLiteral("checkBox_12"));
        sizePolicy1.setHeightForWidth(checkBox_12->sizePolicy().hasHeightForWidth());
        checkBox_12->setSizePolicy(sizePolicy1);
        checkBox_12->setFont(font);

        horizontalLayout_19->addWidget(checkBox_12);

        checkBox_32 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_32->setObjectName(QStringLiteral("checkBox_32"));
        sizePolicy1.setHeightForWidth(checkBox_32->sizePolicy().hasHeightForWidth());
        checkBox_32->setSizePolicy(sizePolicy1);

        horizontalLayout_19->addWidget(checkBox_32);

        checkBox_23 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_23->setObjectName(QStringLiteral("checkBox_23"));

        horizontalLayout_19->addWidget(checkBox_23);

        pushButton_7 = new QPushButton(scrollAreaWidgetContents);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        sizePolicy1.setHeightForWidth(pushButton_7->sizePolicy().hasHeightForWidth());
        pushButton_7->setSizePolicy(sizePolicy1);
        QPalette palette22;
        palette22.setBrush(QPalette::Active, QPalette::Text, brush);
        palette22.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette22.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette22.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette22.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette22.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        pushButton_7->setPalette(palette22);
        pushButton_7->setFont(font);

        horizontalLayout_19->addWidget(pushButton_7);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_15);


        verticalLayout_2->addLayout(horizontalLayout_19);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_18 = new QLabel(scrollAreaWidgetContents);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setFont(font);

        horizontalLayout_16->addWidget(label_18);

        spinBox_4 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_4->setObjectName(QStringLiteral("spinBox_4"));
        spinBox_4->setEnabled(false);
        sizePolicy1.setHeightForWidth(spinBox_4->sizePolicy().hasHeightForWidth());
        spinBox_4->setSizePolicy(sizePolicy1);
        QPalette palette23;
        palette23.setBrush(QPalette::Active, QPalette::Text, brush);
        palette23.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette23.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette23.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette23.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette23.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        spinBox_4->setPalette(palette23);
        spinBox_4->setMaximum(9999);

        horizontalLayout_16->addWidget(spinBox_4);

        label_21 = new QLabel(scrollAreaWidgetContents);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setFont(font);

        horizontalLayout_16->addWidget(label_21);

        spinBox_5 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_5->setObjectName(QStringLiteral("spinBox_5"));
        spinBox_5->setEnabled(false);
        sizePolicy1.setHeightForWidth(spinBox_5->sizePolicy().hasHeightForWidth());
        spinBox_5->setSizePolicy(sizePolicy1);
        QPalette palette24;
        palette24.setBrush(QPalette::Active, QPalette::Text, brush);
        palette24.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette24.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette24.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette24.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette24.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        spinBox_5->setPalette(palette24);
        spinBox_5->setMaximum(99999);

        horizontalLayout_16->addWidget(spinBox_5);

        label_25 = new QLabel(scrollAreaWidgetContents);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setFont(font);

        horizontalLayout_16->addWidget(label_25);

        checkBox_14 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_14->setObjectName(QStringLiteral("checkBox_14"));
        checkBox_14->setFont(font);

        horizontalLayout_16->addWidget(checkBox_14);

        checkBox_15 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_15->setObjectName(QStringLiteral("checkBox_15"));
        checkBox_15->setFont(font);

        horizontalLayout_16->addWidget(checkBox_15);

        label_28 = new QLabel(scrollAreaWidgetContents);
        label_28->setObjectName(QStringLiteral("label_28"));
        QPalette palette25;
        palette25.setBrush(QPalette::Active, QPalette::Text, brush);
        palette25.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette25.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette25.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette25.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette25.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_28->setPalette(palette25);

        horizontalLayout_16->addWidget(label_28);

        spinBox_7 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_7->setObjectName(QStringLiteral("spinBox_7"));
        spinBox_7->setEnabled(false);
        QPalette palette26;
        palette26.setBrush(QPalette::Active, QPalette::Text, brush);
        palette26.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette26.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette26.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette26.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette26.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        spinBox_7->setPalette(palette26);
        spinBox_7->setMinimum(1);
        spinBox_7->setMaximum(9999);

        horizontalLayout_16->addWidget(spinBox_7);

        label_29 = new QLabel(scrollAreaWidgetContents);
        label_29->setObjectName(QStringLiteral("label_29"));
        QPalette palette27;
        palette27.setBrush(QPalette::Active, QPalette::Text, brush);
        palette27.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette27.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette27.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette27.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette27.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_29->setPalette(palette27);

        horizontalLayout_16->addWidget(label_29);

        spinBox_8 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_8->setObjectName(QStringLiteral("spinBox_8"));
        spinBox_8->setEnabled(false);
        QPalette palette28;
        palette28.setBrush(QPalette::Active, QPalette::Text, brush);
        palette28.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette28.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette28.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette28.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette28.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        spinBox_8->setPalette(palette28);
        spinBox_8->setMinimum(1);
        spinBox_8->setMaximum(9999);

        horizontalLayout_16->addWidget(spinBox_8);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_14);


        verticalLayout_2->addLayout(horizontalLayout_16);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        label_32 = new QLabel(scrollAreaWidgetContents);
        label_32->setObjectName(QStringLiteral("label_32"));
        sizePolicy3.setHeightForWidth(label_32->sizePolicy().hasHeightForWidth());
        label_32->setSizePolicy(sizePolicy3);

        horizontalLayout_24->addWidget(label_32);

        lineEdit_25 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_25->setObjectName(QStringLiteral("lineEdit_25"));
        sizePolicy1.setHeightForWidth(lineEdit_25->sizePolicy().hasHeightForWidth());
        lineEdit_25->setSizePolicy(sizePolicy1);

        horizontalLayout_24->addWidget(lineEdit_25);

        label_33 = new QLabel(scrollAreaWidgetContents);
        label_33->setObjectName(QStringLiteral("label_33"));
        sizePolicy3.setHeightForWidth(label_33->sizePolicy().hasHeightForWidth());
        label_33->setSizePolicy(sizePolicy3);

        horizontalLayout_24->addWidget(label_33);

        lineEdit_26 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_26->setObjectName(QStringLiteral("lineEdit_26"));
        sizePolicy1.setHeightForWidth(lineEdit_26->sizePolicy().hasHeightForWidth());
        lineEdit_26->setSizePolicy(sizePolicy1);

        horizontalLayout_24->addWidget(lineEdit_26);

        pushButton_11 = new QPushButton(scrollAreaWidgetContents);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        sizePolicy1.setHeightForWidth(pushButton_11->sizePolicy().hasHeightForWidth());
        pushButton_11->setSizePolicy(sizePolicy1);

        horizontalLayout_24->addWidget(pushButton_11);

        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_24->addItem(horizontalSpacer_20);


        verticalLayout_2->addLayout(horizontalLayout_24);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_23 = new QLabel(scrollAreaWidgetContents);
        label_23->setObjectName(QStringLiteral("label_23"));
        sizePolicy3.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy3);

        horizontalLayout_8->addWidget(label_23);

        lineEdit_5 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        sizePolicy1.setHeightForWidth(lineEdit_5->sizePolicy().hasHeightForWidth());
        lineEdit_5->setSizePolicy(sizePolicy1);
        QPalette palette29;
        palette29.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette29.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette29.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette29.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        QBrush brush16(QColor(143, 146, 147, 255));
        brush16.setStyle(Qt::SolidPattern);
        palette29.setBrush(QPalette::Disabled, QPalette::WindowText, brush16);
        palette29.setBrush(QPalette::Disabled, QPalette::Text, brush16);
        lineEdit_5->setPalette(palette29);

        horizontalLayout_8->addWidget(lineEdit_5);

        label_24 = new QLabel(scrollAreaWidgetContents);
        label_24->setObjectName(QStringLiteral("label_24"));
        sizePolicy3.setHeightForWidth(label_24->sizePolicy().hasHeightForWidth());
        label_24->setSizePolicy(sizePolicy3);

        horizontalLayout_8->addWidget(label_24);

        lineEdit_8 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        sizePolicy1.setHeightForWidth(lineEdit_8->sizePolicy().hasHeightForWidth());
        lineEdit_8->setSizePolicy(sizePolicy1);
        QPalette palette30;
        palette30.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette30.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette30.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette30.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette30.setBrush(QPalette::Disabled, QPalette::WindowText, brush16);
        palette30.setBrush(QPalette::Disabled, QPalette::Text, brush16);
        lineEdit_8->setPalette(palette30);

        horizontalLayout_8->addWidget(lineEdit_8);

        label_45 = new QLabel(scrollAreaWidgetContents);
        label_45->setObjectName(QStringLiteral("label_45"));

        horizontalLayout_8->addWidget(label_45);

        lineEdit_20 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_20->setObjectName(QStringLiteral("lineEdit_20"));
        sizePolicy1.setHeightForWidth(lineEdit_20->sizePolicy().hasHeightForWidth());
        lineEdit_20->setSizePolicy(sizePolicy1);

        horizontalLayout_8->addWidget(lineEdit_20);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_7);


        verticalLayout_2->addLayout(horizontalLayout_8);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        label_26 = new QLabel(scrollAreaWidgetContents);
        label_26->setObjectName(QStringLiteral("label_26"));
        sizePolicy3.setHeightForWidth(label_26->sizePolicy().hasHeightForWidth());
        label_26->setSizePolicy(sizePolicy3);
        QPalette palette31;
        palette31.setBrush(QPalette::Active, QPalette::Text, brush);
        palette31.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette31.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette31.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette31.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette31.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_26->setPalette(palette31);

        horizontalLayout_23->addWidget(label_26);

        lineEdit_10 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));
        sizePolicy1.setHeightForWidth(lineEdit_10->sizePolicy().hasHeightForWidth());
        lineEdit_10->setSizePolicy(sizePolicy1);
        QPalette palette32;
        palette32.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette32.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        QBrush brush17(QColor(78, 0, 0, 255));
        brush17.setStyle(Qt::SolidPattern);
        palette32.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        lineEdit_10->setPalette(palette32);

        horizontalLayout_23->addWidget(lineEdit_10);

        label_27 = new QLabel(scrollAreaWidgetContents);
        label_27->setObjectName(QStringLiteral("label_27"));
        sizePolicy3.setHeightForWidth(label_27->sizePolicy().hasHeightForWidth());
        label_27->setSizePolicy(sizePolicy3);

        horizontalLayout_23->addWidget(label_27);

        lineEdit_13 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_13->setObjectName(QStringLiteral("lineEdit_13"));
        sizePolicy1.setHeightForWidth(lineEdit_13->sizePolicy().hasHeightForWidth());
        lineEdit_13->setSizePolicy(sizePolicy1);
        QPalette palette33;
        palette33.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette33.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette33.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        lineEdit_13->setPalette(palette33);

        horizontalLayout_23->addWidget(lineEdit_13);

        label_46 = new QLabel(scrollAreaWidgetContents);
        label_46->setObjectName(QStringLiteral("label_46"));

        horizontalLayout_23->addWidget(label_46);

        lineEdit_21 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_21->setObjectName(QStringLiteral("lineEdit_21"));
        sizePolicy1.setHeightForWidth(lineEdit_21->sizePolicy().hasHeightForWidth());
        lineEdit_21->setSizePolicy(sizePolicy1);

        horizontalLayout_23->addWidget(lineEdit_21);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_19);


        verticalLayout_2->addLayout(horizontalLayout_23);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        label_30 = new QLabel(scrollAreaWidgetContents);
        label_30->setObjectName(QStringLiteral("label_30"));
        sizePolicy3.setHeightForWidth(label_30->sizePolicy().hasHeightForWidth());
        label_30->setSizePolicy(sizePolicy3);
        QPalette palette34;
        palette34.setBrush(QPalette::Active, QPalette::Text, brush);
        palette34.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette34.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette34.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette34.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette34.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_30->setPalette(palette34);

        horizontalLayout_25->addWidget(label_30);

        lineEdit_14 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_14->setObjectName(QStringLiteral("lineEdit_14"));
        sizePolicy1.setHeightForWidth(lineEdit_14->sizePolicy().hasHeightForWidth());
        lineEdit_14->setSizePolicy(sizePolicy1);
        QPalette palette35;
        palette35.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette35.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette35.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        lineEdit_14->setPalette(palette35);

        horizontalLayout_25->addWidget(lineEdit_14);

        lineEdit_15 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_15->setObjectName(QStringLiteral("lineEdit_15"));
        sizePolicy1.setHeightForWidth(lineEdit_15->sizePolicy().hasHeightForWidth());
        lineEdit_15->setSizePolicy(sizePolicy1);
        QPalette palette36;
        palette36.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette36.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette36.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        lineEdit_15->setPalette(palette36);

        horizontalLayout_25->addWidget(lineEdit_15);

        label_31 = new QLabel(scrollAreaWidgetContents);
        label_31->setObjectName(QStringLiteral("label_31"));
        sizePolicy3.setHeightForWidth(label_31->sizePolicy().hasHeightForWidth());
        label_31->setSizePolicy(sizePolicy3);
        QPalette palette37;
        palette37.setBrush(QPalette::Active, QPalette::Text, brush);
        palette37.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette37.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette37.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette37.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette37.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_31->setPalette(palette37);

        horizontalLayout_25->addWidget(label_31);

        lineEdit_16 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_16->setObjectName(QStringLiteral("lineEdit_16"));
        sizePolicy1.setHeightForWidth(lineEdit_16->sizePolicy().hasHeightForWidth());
        lineEdit_16->setSizePolicy(sizePolicy1);
        QPalette palette38;
        palette38.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette38.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette38.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        lineEdit_16->setPalette(palette38);

        horizontalLayout_25->addWidget(lineEdit_16);

        lineEdit_17 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_17->setObjectName(QStringLiteral("lineEdit_17"));
        sizePolicy1.setHeightForWidth(lineEdit_17->sizePolicy().hasHeightForWidth());
        lineEdit_17->setSizePolicy(sizePolicy1);
        QPalette palette39;
        palette39.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette39.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette39.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        lineEdit_17->setPalette(palette39);

        horizontalLayout_25->addWidget(lineEdit_17);

        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_21);


        verticalLayout_2->addLayout(horizontalLayout_25);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_15 = new QLabel(scrollAreaWidgetContents);
        label_15->setObjectName(QStringLiteral("label_15"));
        sizePolicy.setHeightForWidth(label_15->sizePolicy().hasHeightForWidth());
        label_15->setSizePolicy(sizePolicy);
        label_15->setFont(font);

        horizontalLayout_12->addWidget(label_15);

        lineEdit_6 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setEnabled(false);
        sizePolicy1.setHeightForWidth(lineEdit_6->sizePolicy().hasHeightForWidth());
        lineEdit_6->setSizePolicy(sizePolicy1);
        QPalette palette40;
        palette40.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette40.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette40.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette40.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette40.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette40.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette40.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette40.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette40.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette40.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette40.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette40.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_6->setPalette(palette40);
        lineEdit_6->setFont(font);

        horizontalLayout_12->addWidget(lineEdit_6);

        label_14 = new QLabel(scrollAreaWidgetContents);
        label_14->setObjectName(QStringLiteral("label_14"));
        sizePolicy.setHeightForWidth(label_14->sizePolicy().hasHeightForWidth());
        label_14->setSizePolicy(sizePolicy);
        label_14->setFont(font);

        horizontalLayout_12->addWidget(label_14);

        lineEdit_7 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setEnabled(false);
        sizePolicy1.setHeightForWidth(lineEdit_7->sizePolicy().hasHeightForWidth());
        lineEdit_7->setSizePolicy(sizePolicy1);
        QPalette palette41;
        palette41.setBrush(QPalette::Active, QPalette::WindowText, brush5);
        palette41.setBrush(QPalette::Active, QPalette::Text, brush5);
        palette41.setBrush(QPalette::Active, QPalette::ButtonText, brush5);
        palette41.setBrush(QPalette::Active, QPalette::ToolTipText, brush5);
        palette41.setBrush(QPalette::Inactive, QPalette::WindowText, brush5);
        palette41.setBrush(QPalette::Inactive, QPalette::Text, brush5);
        palette41.setBrush(QPalette::Inactive, QPalette::ButtonText, brush5);
        palette41.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush5);
        palette41.setBrush(QPalette::Disabled, QPalette::WindowText, brush5);
        palette41.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette41.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        palette41.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush5);
        lineEdit_7->setPalette(palette41);
        lineEdit_7->setFont(font);

        horizontalLayout_12->addWidget(lineEdit_7);

        label_19 = new QLabel(scrollAreaWidgetContents);
        label_19->setObjectName(QStringLiteral("label_19"));
        sizePolicy.setHeightForWidth(label_19->sizePolicy().hasHeightForWidth());
        label_19->setSizePolicy(sizePolicy);
        label_19->setFont(font);

        horizontalLayout_12->addWidget(label_19);

        doubleSpinBox_3 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_3->setObjectName(QStringLiteral("doubleSpinBox_3"));
        doubleSpinBox_3->setEnabled(false);
        sizePolicy1.setHeightForWidth(doubleSpinBox_3->sizePolicy().hasHeightForWidth());
        doubleSpinBox_3->setSizePolicy(sizePolicy1);
        doubleSpinBox_3->setFrame(false);
        doubleSpinBox_3->setDecimals(5);
        doubleSpinBox_3->setSingleStep(0.05);

        horizontalLayout_12->addWidget(doubleSpinBox_3);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_9);


        verticalLayout_2->addLayout(horizontalLayout_12);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        pushButton_9 = new QPushButton(scrollAreaWidgetContents);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        sizePolicy1.setHeightForWidth(pushButton_9->sizePolicy().hasHeightForWidth());
        pushButton_9->setSizePolicy(sizePolicy1);

        horizontalLayout_36->addWidget(pushButton_9);

        lineEdit_22 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_22->setObjectName(QStringLiteral("lineEdit_22"));
        sizePolicy1.setHeightForWidth(lineEdit_22->sizePolicy().hasHeightForWidth());
        lineEdit_22->setSizePolicy(sizePolicy1);

        horizontalLayout_36->addWidget(lineEdit_22);

        label_48 = new QLabel(scrollAreaWidgetContents);
        label_48->setObjectName(QStringLiteral("label_48"));
        sizePolicy.setHeightForWidth(label_48->sizePolicy().hasHeightForWidth());
        label_48->setSizePolicy(sizePolicy);
        QPalette palette42;
        palette42.setBrush(QPalette::Active, QPalette::Text, brush);
        palette42.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette42.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette42.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette42.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette42.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_48->setPalette(palette42);

        horizontalLayout_36->addWidget(label_48);

        pushButton_10 = new QPushButton(scrollAreaWidgetContents);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        sizePolicy1.setHeightForWidth(pushButton_10->sizePolicy().hasHeightForWidth());
        pushButton_10->setSizePolicy(sizePolicy1);

        horizontalLayout_36->addWidget(pushButton_10);

        lineEdit_23 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_23->setObjectName(QStringLiteral("lineEdit_23"));
        sizePolicy1.setHeightForWidth(lineEdit_23->sizePolicy().hasHeightForWidth());
        lineEdit_23->setSizePolicy(sizePolicy1);

        horizontalLayout_36->addWidget(lineEdit_23);

        label_49 = new QLabel(scrollAreaWidgetContents);
        label_49->setObjectName(QStringLiteral("label_49"));
        sizePolicy.setHeightForWidth(label_49->sizePolicy().hasHeightForWidth());
        label_49->setSizePolicy(sizePolicy);
        QPalette palette43;
        palette43.setBrush(QPalette::Active, QPalette::Text, brush);
        palette43.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette43.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette43.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette43.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette43.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        label_49->setPalette(palette43);

        horizontalLayout_36->addWidget(label_49);

        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_25);


        verticalLayout_2->addLayout(horizontalLayout_36);

        line_2 = new QFrame(scrollAreaWidgetContents);
        line_2->setObjectName(QStringLiteral("line_2"));
        sizePolicy2.setHeightForWidth(line_2->sizePolicy().hasHeightForWidth());
        line_2->setSizePolicy(sizePolicy2);
        QPalette palette44;
        palette44.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette44.setBrush(QPalette::Active, QPalette::Button, brush10);
        palette44.setBrush(QPalette::Active, QPalette::Light, brush11);
        palette44.setBrush(QPalette::Active, QPalette::Midlight, brush12);
        palette44.setBrush(QPalette::Active, QPalette::Dark, brush13);
        palette44.setBrush(QPalette::Active, QPalette::Mid, brush14);
        palette44.setBrush(QPalette::Active, QPalette::Text, brush);
        palette44.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette44.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette44.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette44.setBrush(QPalette::Active, QPalette::Window, brush10);
        palette44.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette44.setBrush(QPalette::Active, QPalette::AlternateBase, brush15);
        palette44.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette44.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette44.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette44.setBrush(QPalette::Inactive, QPalette::Button, brush10);
        palette44.setBrush(QPalette::Inactive, QPalette::Light, brush11);
        palette44.setBrush(QPalette::Inactive, QPalette::Midlight, brush12);
        palette44.setBrush(QPalette::Inactive, QPalette::Dark, brush13);
        palette44.setBrush(QPalette::Inactive, QPalette::Mid, brush14);
        palette44.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette44.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette44.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette44.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette44.setBrush(QPalette::Inactive, QPalette::Window, brush10);
        palette44.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette44.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush15);
        palette44.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette44.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette44.setBrush(QPalette::Disabled, QPalette::WindowText, brush13);
        palette44.setBrush(QPalette::Disabled, QPalette::Button, brush10);
        palette44.setBrush(QPalette::Disabled, QPalette::Light, brush11);
        palette44.setBrush(QPalette::Disabled, QPalette::Midlight, brush12);
        palette44.setBrush(QPalette::Disabled, QPalette::Dark, brush13);
        palette44.setBrush(QPalette::Disabled, QPalette::Mid, brush14);
        palette44.setBrush(QPalette::Disabled, QPalette::Text, brush13);
        palette44.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette44.setBrush(QPalette::Disabled, QPalette::ButtonText, brush13);
        palette44.setBrush(QPalette::Disabled, QPalette::Base, brush10);
        palette44.setBrush(QPalette::Disabled, QPalette::Window, brush10);
        palette44.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette44.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush10);
        palette44.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette44.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        line_2->setPalette(palette44);
        line_2->setFrameShadow(QFrame::Sunken);
        line_2->setLineWidth(2);
        line_2->setFrameShape(QFrame::HLine);

        verticalLayout_2->addWidget(line_2);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        pushButton_8 = new QPushButton(scrollAreaWidgetContents);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        sizePolicy1.setHeightForWidth(pushButton_8->sizePolicy().hasHeightForWidth());
        pushButton_8->setSizePolicy(sizePolicy1);
        pushButton_8->setIcon(icon3);

        horizontalLayout_27->addWidget(pushButton_8);

        lineEdit_24 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_24->setObjectName(QStringLiteral("lineEdit_24"));
        sizePolicy1.setHeightForWidth(lineEdit_24->sizePolicy().hasHeightForWidth());
        lineEdit_24->setSizePolicy(sizePolicy1);

        horizontalLayout_27->addWidget(lineEdit_24);

        horizontalSpacer_8 = new QSpacerItem(158, 17, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_8);


        verticalLayout_7->addLayout(horizontalLayout_27);

        plainTextEdit_2 = new QPlainTextEdit(scrollAreaWidgetContents);
        plainTextEdit_2->setObjectName(QStringLiteral("plainTextEdit_2"));
        sizePolicy3.setHeightForWidth(plainTextEdit_2->sizePolicy().hasHeightForWidth());
        plainTextEdit_2->setSizePolicy(sizePolicy3);
        QPalette palette45;
        palette45.setBrush(QPalette::Active, QPalette::Text, brush);
        palette45.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette45.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette45.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette45.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette45.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        plainTextEdit_2->setPalette(palette45);

        verticalLayout_7->addWidget(plainTextEdit_2);


        horizontalLayout_28->addLayout(verticalLayout_7);

        customPlot_4 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_4->setObjectName(QStringLiteral("customPlot_4"));

        horizontalLayout_28->addWidget(customPlot_4);


        verticalLayout_2->addLayout(horizontalLayout_28);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));

        verticalLayout_2->addLayout(horizontalLayout_14);

        verticalSpacer = new QSpacerItem(539, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        pushButton = new QPushButton(scrollAreaWidgetContents);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);
        QPalette palette46;
        palette46.setBrush(QPalette::Active, QPalette::Text, brush);
        palette46.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette46.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette46.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette46.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette46.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        pushButton->setPalette(palette46);
        pushButton->setFont(font);

        horizontalLayout_6->addWidget(pushButton);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_3);


        verticalLayout_2->addLayout(horizontalLayout_6);


        verticalLayout_6->addLayout(verticalLayout_2);


        gridLayout_2->addLayout(verticalLayout_6, 0, 0, 1, 1);

        line_3 = new QFrame(scrollAreaWidgetContents);
        line_3->setObjectName(QStringLiteral("line_3"));
        QPalette palette47;
        palette47.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette47.setBrush(QPalette::Active, QPalette::Button, brush10);
        palette47.setBrush(QPalette::Active, QPalette::Light, brush11);
        palette47.setBrush(QPalette::Active, QPalette::Midlight, brush12);
        palette47.setBrush(QPalette::Active, QPalette::Dark, brush13);
        palette47.setBrush(QPalette::Active, QPalette::Mid, brush14);
        palette47.setBrush(QPalette::Active, QPalette::Text, brush);
        palette47.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette47.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette47.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette47.setBrush(QPalette::Active, QPalette::Window, brush10);
        palette47.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette47.setBrush(QPalette::Active, QPalette::AlternateBase, brush15);
        palette47.setBrush(QPalette::Active, QPalette::ToolTipBase, brush4);
        palette47.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette47.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette47.setBrush(QPalette::Inactive, QPalette::Button, brush10);
        palette47.setBrush(QPalette::Inactive, QPalette::Light, brush11);
        palette47.setBrush(QPalette::Inactive, QPalette::Midlight, brush12);
        palette47.setBrush(QPalette::Inactive, QPalette::Dark, brush13);
        palette47.setBrush(QPalette::Inactive, QPalette::Mid, brush14);
        palette47.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette47.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette47.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette47.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette47.setBrush(QPalette::Inactive, QPalette::Window, brush10);
        palette47.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette47.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush15);
        palette47.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush4);
        palette47.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette47.setBrush(QPalette::Disabled, QPalette::WindowText, brush13);
        palette47.setBrush(QPalette::Disabled, QPalette::Button, brush10);
        palette47.setBrush(QPalette::Disabled, QPalette::Light, brush11);
        palette47.setBrush(QPalette::Disabled, QPalette::Midlight, brush12);
        palette47.setBrush(QPalette::Disabled, QPalette::Dark, brush13);
        palette47.setBrush(QPalette::Disabled, QPalette::Mid, brush14);
        palette47.setBrush(QPalette::Disabled, QPalette::Text, brush13);
        palette47.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette47.setBrush(QPalette::Disabled, QPalette::ButtonText, brush13);
        palette47.setBrush(QPalette::Disabled, QPalette::Base, brush10);
        palette47.setBrush(QPalette::Disabled, QPalette::Window, brush10);
        palette47.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette47.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush10);
        palette47.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush4);
        palette47.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        line_3->setPalette(palette47);
        line_3->setFrameShadow(QFrame::Raised);
        line_3->setLineWidth(2);
        line_3->setFrameShape(QFrame::VLine);

        gridLayout_2->addWidget(line_3, 0, 1, 1, 1);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        label_8 = new QLabel(scrollAreaWidgetContents);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font);

        verticalLayout_5->addWidget(label_8);

        customPlot = new QCustomPlot(scrollAreaWidgetContents);
        customPlot->setObjectName(QStringLiteral("customPlot"));
        QSizePolicy sizePolicy6(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(customPlot->sizePolicy().hasHeightForWidth());
        customPlot->setSizePolicy(sizePolicy6);
        customPlot->setMinimumSize(QSize(300, 0));

        verticalLayout_5->addWidget(customPlot);

        checkBox_22 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_22->setObjectName(QStringLiteral("checkBox_22"));

        verticalLayout_5->addWidget(checkBox_22);

        customPlot_2 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_2->setObjectName(QStringLiteral("customPlot_2"));
        sizePolicy6.setHeightForWidth(customPlot_2->sizePolicy().hasHeightForWidth());
        customPlot_2->setSizePolicy(sizePolicy6);
        customPlot_2->setMinimumSize(QSize(300, 0));

        verticalLayout_5->addWidget(customPlot_2);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        label_13 = new QLabel(scrollAreaWidgetContents);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setFont(font);

        horizontalLayout_21->addWidget(label_13);

        doubleSpinBox_5 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_5->setObjectName(QStringLiteral("doubleSpinBox_5"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_5->sizePolicy().hasHeightForWidth());
        doubleSpinBox_5->setSizePolicy(sizePolicy1);
        QPalette palette48;
        palette48.setBrush(QPalette::Active, QPalette::Text, brush);
        palette48.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette48.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette48.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette48.setBrush(QPalette::Disabled, QPalette::Text, brush5);
        palette48.setBrush(QPalette::Disabled, QPalette::ButtonText, brush5);
        doubleSpinBox_5->setPalette(palette48);
        doubleSpinBox_5->setSingleStep(0.1);
        doubleSpinBox_5->setValue(0.3);

        horizontalLayout_21->addWidget(doubleSpinBox_5);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_23);


        verticalLayout_5->addLayout(horizontalLayout_21);

        customPlot_3 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_3->setObjectName(QStringLiteral("customPlot_3"));
        QSizePolicy sizePolicy7(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(customPlot_3->sizePolicy().hasHeightForWidth());
        customPlot_3->setSizePolicy(sizePolicy7);
        customPlot_3->setMinimumSize(QSize(300, 0));
        customPlot_3->setStyleSheet(QStringLiteral(""));

        verticalLayout_5->addWidget(customPlot_3);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        pushButton_6 = new QPushButton(scrollAreaWidgetContents);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        sizePolicy1.setHeightForWidth(pushButton_6->sizePolicy().hasHeightForWidth());
        pushButton_6->setSizePolicy(sizePolicy1);
        pushButton_6->setFont(font);
        pushButton_6->setAutoFillBackground(false);

        horizontalLayout_20->addWidget(pushButton_6);

        checkBox_10 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_10->setObjectName(QStringLiteral("checkBox_10"));
        checkBox_10->setFont(font);

        horizontalLayout_20->addWidget(checkBox_10);

        spinBox_6 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_6->setObjectName(QStringLiteral("spinBox_6"));
        spinBox_6->setEnabled(false);
        QPalette palette49;
        palette49.setBrush(QPalette::Active, QPalette::Text, brush);
        palette49.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette49.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette49.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette49.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette49.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        spinBox_6->setPalette(palette49);
        spinBox_6->setMaximum(9999);

        horizontalLayout_20->addWidget(spinBox_6);

        checkBox_33 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_33->setObjectName(QStringLiteral("checkBox_33"));

        horizontalLayout_20->addWidget(checkBox_33);

        doubleSpinBox_14 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_14->setObjectName(QStringLiteral("doubleSpinBox_14"));
        doubleSpinBox_14->setDecimals(4);
        doubleSpinBox_14->setMaximum(9999.99);

        horizontalLayout_20->addWidget(doubleSpinBox_14);

        label_47 = new QLabel(scrollAreaWidgetContents);
        label_47->setObjectName(QStringLiteral("label_47"));
        QPalette palette50;
        palette50.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette50.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette50.setBrush(QPalette::Disabled, QPalette::WindowText, brush17);
        label_47->setPalette(palette50);

        horizontalLayout_20->addWidget(label_47);

        doubleSpinBox_15 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_15->setObjectName(QStringLiteral("doubleSpinBox_15"));
        doubleSpinBox_15->setDecimals(4);
        doubleSpinBox_15->setMaximum(9999.99);

        horizontalLayout_20->addWidget(doubleSpinBox_15);

        checkBox_19 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_19->setObjectName(QStringLiteral("checkBox_19"));

        horizontalLayout_20->addWidget(checkBox_19);

        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_16);


        verticalLayout_5->addLayout(horizontalLayout_20);


        gridLayout_2->addLayout(verticalLayout_5, 0, 2, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(scrollArea, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 2307, 33));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QStringLiteral("menuTools"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(doubleSpinBox, doubleSpinBox_2);
        QWidget::setTabOrder(doubleSpinBox_2, checkBox);
        QWidget::setTabOrder(checkBox, lineEdit);
        QWidget::setTabOrder(lineEdit, spinBox);
        QWidget::setTabOrder(spinBox, spinBox_2);
        QWidget::setTabOrder(spinBox_2, checkBox_2);
        QWidget::setTabOrder(checkBox_2, lineEdit_2);
        QWidget::setTabOrder(lineEdit_2, lineEdit_3);
        QWidget::setTabOrder(lineEdit_3, lineEdit_4);
        QWidget::setTabOrder(lineEdit_4, pushButton);
        QWidget::setTabOrder(pushButton, plainTextEdit);

        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuTools->addAction(actionSpectrum_Plotter);
        menuTools->addAction(actionCorrelation);
        menuTools->addAction(actionEditor);
        menuTools->addAction(actionArithmetic);
        menuHelp->addAction(actionAbout);
        menuHelp->addAction(actionBug_Report);
        menuHelp->addAction(actionManual);
        mainToolBar->addAction(actionSpectrum_Plotter);
        mainToolBar->addAction(actionCorrelation);

        retranslateUi(MainWindow);
        QObject::connect(pushButton, SIGNAL(clicked()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionSpectrum_Plotter->setText(QApplication::translate("MainWindow", "Spectrum Plotter", Q_NULLPTR));
        actionAbout->setText(QApplication::translate("MainWindow", "About", Q_NULLPTR));
        actionBug_Report->setText(QApplication::translate("MainWindow", "Bug Report", Q_NULLPTR));
        actionCorrelation->setText(QApplication::translate("MainWindow", "Correlation", Q_NULLPTR));
        actionEditor->setText(QApplication::translate("MainWindow", "Editor", Q_NULLPTR));
        actionArithmetic->setText(QApplication::translate("MainWindow", "Arithmetic", Q_NULLPTR));
        actionManual->setText(QApplication::translate("MainWindow", "Manual", Q_NULLPTR));
        label_4->setText(QString());
        label_10->setText(QString());
        checkBox->setText(QApplication::translate("MainWindow", "CroCo", Q_NULLPTR));
        lineEdit->setText(QString());
        label_2->setText(QApplication::translate("MainWindow", ".txt from", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "to", Q_NULLPTR));
        checkBox_27->setText(QApplication::translate("MainWindow", "Sequence", Q_NULLPTR));
        checkBox_13->setText(QApplication::translate("MainWindow", "flip", Q_NULLPTR));
        checkBox_2->setText(QApplication::translate("MainWindow", "your file", Q_NULLPTR));
        lineEdit_2->setText(QString());
        checkBox_16->setText(QApplication::translate("MainWindow", "Unknown; Times:", Q_NULLPTR));
        label_34->setText(QApplication::translate("MainWindow", "lock", Q_NULLPTR));
        checkBox_18->setText(QApplication::translate("MainWindow", "P", Q_NULLPTR));
        checkBox_17->setText(QApplication::translate("MainWindow", "e", Q_NULLPTR));
        checkBox_35->setText(QApplication::translate("MainWindow", "T0", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Rebined spectra:", Q_NULLPTR));
        lineEdit_3->setText(QString());
        label_9->setText(QApplication::translate("MainWindow", "to", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">_*</span></p></body></html>", Q_NULLPTR));
        label_22->setText(QApplication::translate("MainWindow", "Flux Ratio A/B:", Q_NULLPTR));
        label_16->setText(QApplication::translate("MainWindow", "FITS Extension:", Q_NULLPTR));
        lineEdit_9->setText(QString());
        label_17->setText(QApplication::translate("MainWindow", "Col. Wavel.", Q_NULLPTR));
        lineEdit_11->setText(QString());
        label_20->setText(QApplication::translate("MainWindow", "Col. Intens", Q_NULLPTR));
        lineEdit_12->setText(QString());
        label_11->setText(QApplication::translate("MainWindow", "Path to work folder", Q_NULLPTR));
        lineEdit_4->setText(QString());
        pushButton_2->setText(QApplication::translate("MainWindow", "Read Data", Q_NULLPTR));
        checkBox_7->setText(QApplication::translate("MainWindow", "Bidiagonal matrix", Q_NULLPTR));
        checkBox_8->setText(QApplication::translate("MainWindow", "Static Lines", Q_NULLPTR));
        checkBox_3->setText(QApplication::translate("MainWindow", "SB1", Q_NULLPTR));
        checkBox_4->setText(QApplication::translate("MainWindow", "SB2", Q_NULLPTR));
        checkBox_34->setText(QApplication::translate("MainWindow", "SB3", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "ECON", Q_NULLPTR));
        checkBox_5->setText(QApplication::translate("MainWindow", "standard", Q_NULLPTR));
        checkBox_6->setText(QApplication::translate("MainWindow", "divide-and-conquer", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "SVD", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("MainWindow", "Subtract", Q_NULLPTR));
        checkBox_20->setText(QApplication::translate("MainWindow", "A", Q_NULLPTR));
        checkBox_21->setText(QApplication::translate("MainWindow", "B", Q_NULLPTR));
        checkBox_24->setText(QApplication::translate("MainWindow", "shift A", Q_NULLPTR));
        checkBox_25->setText(QApplication::translate("MainWindow", "shift B", Q_NULLPTR));
        checkBox_26->setText(QApplication::translate("MainWindow", "add", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "max. RV of component 1", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "max. RV of component 2", Q_NULLPTR));
        plainTextEdit->setPlainText(QString());
        pushButton_4->setText(QApplication::translate("MainWindow", "Optimisation", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "# Iterations:", Q_NULLPTR));
        checkBox_9->setText(QApplication::translate("MainWindow", "New", Q_NULLPTR));
        checkBox_11->setText(QApplication::translate("MainWindow", "Continue", Q_NULLPTR));
        checkBox_12->setText(QApplication::translate("MainWindow", "Initial", Q_NULLPTR));
        checkBox_32->setText(QApplication::translate("MainWindow", "Reinitiate", Q_NULLPTR));
        checkBox_23->setText(QApplication::translate("MainWindow", "Auto Stop", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Stop", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "Iteration:", Q_NULLPTR));
        label_21->setText(QApplication::translate("MainWindow", "Evaluation:", Q_NULLPTR));
        label_25->setText(QApplication::translate("MainWindow", "Criterion:", Q_NULLPTR));
        checkBox_14->setText(QApplication::translate("MainWindow", "Mean", Q_NULLPTR));
        checkBox_15->setText(QApplication::translate("MainWindow", "Peak", Q_NULLPTR));
        label_28->setText(QApplication::translate("MainWindow", "# CPU Cores:", Q_NULLPTR));
        label_29->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#000000;\">Use:</span></p></body></html>", Q_NULLPTR));
        label_32->setText(QApplication::translate("MainWindow", "Common Name:", Q_NULLPTR));
        label_33->setText(QApplication::translate("MainWindow", "Extension:", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("MainWindow", "Set File Names", Q_NULLPTR));
        label_23->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Out Component 1:</p></body></html>", Q_NULLPTR));
        label_24->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Out Component 2:</p></body></html>", Q_NULLPTR));
        label_45->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Out Errors:</p></body></html>", Q_NULLPTR));
        label_26->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">Out Static Comp:</span></p></body></html>", Q_NULLPTR));
        label_27->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">Out Differences:</span></p></body></html>", Q_NULLPTR));
        label_46->setText(QApplication::translate("MainWindow", "Log-File", Q_NULLPTR));
        label_30->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">I/O Initial Data:</span></p></body></html>", Q_NULLPTR));
        label_31->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">I/O Optimisation Data:</span></p></body></html>", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "Time:", Q_NULLPTR));
        lineEdit_6->setText(QString());
        label_14->setText(QApplication::translate("MainWindow", "min, residuum", Q_NULLPTR));
        lineEdit_7->setText(QString());
        label_19->setText(QApplication::translate("MainWindow", "Velocity Step Size [km/s]:", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        label_48->setText(QApplication::translate("MainWindow", ".sps", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "Load", Q_NULLPTR));
        label_49->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#000000;\">.sps</span></p></body></html>", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("MainWindow", "Error", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Close", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Result; <span style=\" color:#0000ff;\">Comp A,</span><span style=\" color:#ff0000;\">Comp B </span><span style=\" color:#000000;\">&amp; Error</span></p></body></html>", Q_NULLPTR));
        checkBox_22->setText(QApplication::translate("MainWindow", "Telluric", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Difference; Offset:</p></body></html>", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "Plot", Q_NULLPTR));
        checkBox_10->setText(QApplication::translate("MainWindow", "Live Update", Q_NULLPTR));
        checkBox_33->setText(QApplication::translate("MainWindow", "Compute Residuum from", Q_NULLPTR));
        label_47->setText(QApplication::translate("MainWindow", "<html><head/><body><p>to</p></body></html>", Q_NULLPTR));
        checkBox_19->setText(QApplication::translate("MainWindow", "Save all Updates", Q_NULLPTR));
        menuTools->setTitle(QApplication::translate("MainWindow", "Tools", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
